<?php
// deliti/api/sales/get_sales.php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . '/../config.php';

try {
    // TAMPILKAN SEMUA ORDER - TANPA FILTER STATUS
    $sql = "SELECT 
                o.id,
                o.user_id,
                o.total_price,
                o.status,
                o.created_at,
                u.name as customer_name,
                u.email as customer_email
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.id
            ORDER BY o.created_at DESC";  // ← HAPUS WHERE CLAUSE
    
    $stmt = $pdo->query($sql);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Hitung total SEMUA order (termasuk pending)
    $totalAllOrders = 0;
    $totalCompleted = 0;
    $totalPending = 0;
    
    foreach ($orders as $order) {
        $totalAllOrders += floatval($order['total_price']);
        
        if (in_array($order['status'], ['completed', 'paid', 'delivered', 'done'])) {
            $totalCompleted += floatval($order['total_price']);
        } else {
            $totalPending += floatval($order['total_price']);
        }
    }
    
    // Return response
    echo json_encode([
        'success' => true,
        'data' => $orders,
        'summary' => [
            'total_all_orders' => $totalAllOrders,    // Semua order
            'total_completed' => $totalCompleted,     // Hanya yang selesai
            'total_pending' => $totalPending,         // Yang masih pending
            'total_orders' => count($orders),
            'completed_orders' => count(array_filter($orders, function($o) {
                return in_array($o['status'], ['completed', 'paid', 'delivered', 'done']);
            })),
            'pending_orders' => count(array_filter($orders, function($o) {
                return !in_array($o['status'], ['completed', 'paid', 'delivered', 'done']);
            })),
        ],
        'message' => 'Sales data retrieved successfully'
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage(),
        'data' => [],
        'summary' => [
            'total_all_orders' => 0,
            'total_completed' => 0,
            'total_pending' => 0,
            'total_orders' => 0,
            'completed_orders' => 0,
            'pending_orders' => 0,
        ]
    ]);
}
?>