<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include 'config.php';

// Get POST data
$data = json_decode(file_get_contents("php://input"), true);

if(!empty($data['email']) && !empty($data['password'])) {
    $email = $data['email'];
    $password = $data['password'];
    
    try {
        $stmt = $pdo->prepare("SELECT id, name, email, password, phone, role FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if($user && password_verify($password, $user['password'])) {
            echo json_encode([
                'success' => true,
                'message' => 'Login successful',
                'user' => [
                    'id' => $user['id'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'phone' => $user['phone'] ?? '', // ← ADD THIS
                    'role' => $user['role'] ?? 'user' // ← ADD THIS (IMPORTANT!)
                ]
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Invalid email or password'
            ]);
        }
    } catch(PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Email and password required'
    ]);
}
?>