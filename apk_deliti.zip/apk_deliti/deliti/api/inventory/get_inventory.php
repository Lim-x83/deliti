<?php
require_once '../config.php';

$data = json_decode(file_get_contents("php://input"), true);

try {
    // Get all inventory items
    $stmt = $pdo->query("
        SELECT * FROM inventory 
        ORDER BY expired_date, nama_barang
    ");
    
    $inventory = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => $inventory,
        'total' => count($inventory)
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error fetching inventory: ' . $e->getMessage(),
        'data' => [],
        'total' => 0
    ]);
}
?>