<?php
require_once '../config.php';

$data = json_decode(file_get_contents("php://input"), true);
$id = intval($data['id'] ?? 0);

if ($id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid ID']);
    exit;
}

try {
    $stmt = $pdo->prepare("DELETE FROM inventory WHERE id = ?");
    $stmt->execute([$id]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Inventory item deleted successfully'
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => "Database error: " . $e->getMessage()
    ]);
}
?>