<?php
require_once '../config.php';

$data = json_decode(file_get_contents("php://input"), true);

$required = ['nama_barang', 'kode', 'jumlah_barang', 'satuan_kuantitas'];
foreach($required as $field) {
    if(empty($data[$field])) {
        echo json_encode(['success' => false, 'message' => "$field is required"]);
        exit;
    }
}

try {
    $stmt = $pdo->prepare("
        INSERT INTO inventory (
            nama_barang, kode, jumlah_barang, satuan_kuantitas,
            lokasi_barang, expired_date, harga, vendor
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $data['nama_barang'],
        $data['kode'],
        intval($data['jumlah_barang']),
        $data['satuan_kuantitas'],
        $data['lokasi_barang'] ?? '',
        $data['expired_date'] ?? null,
        $data['harga'] ?? null,
        $data['vendor'] ?? null
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Inventory item added successfully'
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => "Database error: " . $e->getMessage()
    ]);
}
?>