<?php
require_once '../config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Item ID is required']);
    exit();
}

$id = intval($data['id']);

try {
    // Build SQL dynamically based on what fields are provided
    $updates = [];
    $params = [];
    
    if (isset($data['nama_barang'])) {
        $updates[] = "nama_barang = ?";
        $params[] = $data['nama_barang'];
    }
    
    if (isset($data['kode'])) {
        $updates[] = "kode = ?";
        $params[] = $data['kode'];
    }
    
    if (isset($data['jumlah_barang'])) {
        $updates[] = "jumlah_barang = ?";
        $params[] = intval($data['jumlah_barang']);
    }
    
    if (isset($data['satuan_kuantitas'])) {
        $updates[] = "satuan_kuantitas = ?";
        $params[] = $data['satuan_kuantitas'];
    }
    
    if (isset($data['lokasi_barang'])) {
        $updates[] = "lokasi_barang = ?";
        $params[] = $data['lokasi_barang'] ?: null;
    }
    
    if (isset($data['expired_date'])) {
        $updates[] = "expired_date = ?";
        $params[] = $data['expired_date'] ?: null;
    }
    
    // Add id to params
    $params[] = $id;
    
    if (empty($updates)) {
        echo json_encode(['success' => false, 'message' => 'No fields to update']);
        exit();
    }
    
    $sql = "UPDATE inventory SET " . implode(', ', $updates) . " WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    
    if ($stmt->execute($params)) {
        // Also update purchasing table if harga/vendor provided
        if (isset($data['harga']) || isset($data['vendor'])) {
            $purchase_updates = [];
            $purchase_params = [];
            
            if (isset($data['harga'])) {
                $purchase_updates[] = "harga = ?";
                $purchase_params[] = floatval($data['harga']);
            }
            
            if (isset($data['vendor'])) {
                $purchase_updates[] = "vendor = ?";
                $purchase_params[] = $data['vendor'] ?: null;
            }
            
            $purchase_params[] = $id;
            
            if (!empty($purchase_updates)) {
                $purchase_sql = "UPDATE purchasing SET " . implode(', ', $purchase_updates) . " WHERE kode = (SELECT kode FROM inventory WHERE id = ?)";
                $purchase_stmt = $pdo->prepare($purchase_sql);
                $purchase_stmt->execute($purchase_params);
            }
        }
        
        echo json_encode([
            'success' => true,
            'message' => 'Item updated successfully'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update item']);
    }
    
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>