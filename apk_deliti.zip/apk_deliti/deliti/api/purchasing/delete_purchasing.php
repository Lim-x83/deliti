<?php
// api/purchasing/delete_purchasing.php
require_once '../config.php';

$data = json_decode(file_get_contents("php://input"), true);
$id = intval($data['id'] ?? 0);

if ($id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid ID']);
    exit;
}

try {
    // First get the kode to delete from all tables
    $stmt = $pdo->prepare("SELECT kode FROM purchasing WHERE id = ?");
    $stmt->execute([$id]);
    $purchase = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$purchase) {
        echo json_encode(['success' => false, 'message' => 'Purchase not found']);
        exit;
    }
    
    $kode = $purchase['kode'];
    
    // Delete from all 3 tables
    $pdo->beginTransaction();
    
    // Delete from accounts_payable
    $stmt = $pdo->prepare("DELETE FROM accounts_payable WHERE kode = ?");
    $stmt->execute([$kode]);
    
    // Delete from inventory
    $stmt = $pdo->prepare("DELETE FROM inventory WHERE kode = ?");
    $stmt->execute([$kode]);
    
    // Delete from purchasing
    $stmt = $pdo->prepare("DELETE FROM purchasing WHERE id = ?");
    $stmt->execute([$id]);
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Purchase and related records deleted successfully'
    ]);
    
} catch(PDOException $e) {
    $pdo->rollBack();
    echo json_encode([
        'success' => false, 
        'message' => "Database error: " . $e->getMessage()
    ]);
}
?>