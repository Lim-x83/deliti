<?php
// api/purchasing/add_purchasing.php - SIMPLE VERSION
require_once '../config.php';

$data = json_decode(file_get_contents("php://input"), true);

// Log for debugging
error_log("=== ADD PURCHASING CALLED ===");
error_log("Data: " . print_r($data, true));

$required = ['nama_barang', 'jumlah_barang', 'satuan_kuantitas', 'expired_date', 'harga', 'vendor'];
foreach($required as $field) {
    if(empty($data[$field])) {
        echo json_encode(['success' => false, 'message' => "$field is required"]);
        exit;
    }
}

try {
    // ONLY insert into purchasing - triggers will handle inventory and AP
    $stmt = $pdo->prepare("
        INSERT INTO purchasing (
            nama_barang, jumlah_barang, satuan_kuantitas, 
            lokasi_barang, expired_date, harga, vendor
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    
    $success = $stmt->execute([
        $data['nama_barang'],
        intval($data['jumlah_barang']),
        $data['satuan_kuantitas'],
        $data['lokasi_barang'] ?? '',
        $data['expired_date'],
        floatval($data['harga']),
        $data['vendor']
    ]);
    
    if ($success) {
        echo json_encode([
            'success' => true,
            'message' => 'Purchase added successfully'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to add purchase'
        ]);
    }
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => "Database error: " . $e->getMessage()
    ]);
}
?>