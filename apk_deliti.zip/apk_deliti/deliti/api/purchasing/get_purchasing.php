<?php
// api/purchasing/get_purchasing.php
require_once '../config.php';

try {
    $stmt = $pdo->query("
        SELECT * FROM purchasing 
        ORDER BY id DESC
    ");
    
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => $data,
        'count' => count($data)
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => "Database error: " . $e->getMessage(),
        'data' => []
    ]);
}
?>