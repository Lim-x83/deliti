<?php
require_once '../config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Log the request
error_log("Update status request received: " . file_get_contents('php://input'));

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);
error_log("Parsed data: " . print_r($data, true));

if (!isset($data['order_id']) || !isset($data['status'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit();
}

$order_id = intval($data['order_id']);
$status = $data['status'];

// Validate status
$valid_statuses = ['pending', 'preparing', 'cooking', 'ready', 'delivering', 'completed', 'cancelled'];
if (!in_array($status, $valid_statuses)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid status: ' . $status]);
    exit();
}

try {
    // Debug: Check if order exists
    $check = $pdo->prepare("SELECT id FROM orders WHERE id = ?");
    $check->execute([$order_id]);
    if ($check->rowCount() == 0) {
        echo json_encode(['success' => false, 'message' => 'Order not found: ' . $order_id]);
        exit();
    }
    
    // Update order status
    $sql = "UPDATE orders SET status = ? WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    
    if ($stmt->execute([$status, $order_id])) {
        error_log("Order $order_id updated to $status");
        echo json_encode(['success' => true, 'message' => 'Order status updated']);
    } else {
        error_log("Failed to update order $order_id");
        echo json_encode(['success' => false, 'message' => 'Failed to update order status']);
    }
} catch(Exception $e) {
    error_log("Database error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>