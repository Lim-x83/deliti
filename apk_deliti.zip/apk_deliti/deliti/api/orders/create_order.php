<?php
// api/orders/create_order.php - UPDATED VERSION
require_once '../config.php';

$data = json_decode(file_get_contents("php://input"), true);

// Validate required fields
if (empty($data['user_id']) || empty($data['total_price']) || empty($data['items'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

try {
    $pdo->beginTransaction();
    
    // 1. Insert into orders table with ENUM status
    $stmt = $pdo->prepare("
        INSERT INTO orders (user_id, total_price, status) 
        VALUES (?, ?, ?)
    ");
    
    // Use the ENUM value from request or default to 'pending'
    $status = $data['status'] ?? 'pending';
    
    $stmt->execute([
        intval($data['user_id']),
        floatval($data['total_price']),
        $status
    ]);
    
    $orderId = $pdo->lastInsertId();
    
    // 2. Insert order items
    $stmt = $pdo->prepare("
        INSERT INTO order_items (order_id, menu_item_id, quantity, price)
        VALUES (?, ?, ?, ?)
    ");
    
    foreach ($data['items'] as $item) {
        $stmt->execute([
            $orderId,
            intval($item['menu_item_id']),
            intval($item['quantity']),
            floatval($item['price'])
        ]);
    }
    
    // 3. Clear the user's cart after successful order
    $stmt = $pdo->prepare("DELETE FROM cart_items WHERE user_id = ?");
    $stmt->execute([intval($data['user_id'])]);
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Order created successfully',
        'order_id' => $orderId,
        'status' => $status
    ]);
    
} catch(PDOException $e) {
    $pdo->rollBack();
    echo json_encode([
        'success' => false, 
        'message' => "Database error: " . $e->getMessage()
    ]);
}
?>