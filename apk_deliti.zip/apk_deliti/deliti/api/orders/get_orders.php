<?php
require_once '../config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Check if it's admin request (no user_id) or user request
$is_admin_request = empty($_POST) && empty(file_get_contents("php://input"));

if ($is_admin_request) {
    // ADMIN: Get ALL orders
    try {
        $stmt = $pdo->prepare("
            SELECT 
                o.id,
                o.user_id,
                o.total_price,
                o.status,
                DATE_FORMAT(o.created_at, '%Y-%m-%d %H:%i:%s') as created_at,
                u.name as customer_name,
                u.email as customer_email
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.id
            ORDER BY o.created_at DESC
        ");
        
        $stmt->execute();
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch(PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage(),
            'orders' => []
        ]);
        exit;
    }
} else {
    // USER: Get their own orders
    $data = json_decode(file_get_contents("php://input"), true);

    if(empty($data['user_id'])) {
        echo json_encode([
            'success' => false,
            'message' => 'User ID is required',
            'orders' => []
        ]);
        exit;
    }

    $user_id = intval($data['user_id']);

    try {
        $stmt = $pdo->prepare("
            SELECT 
                id,
                user_id,
                total_price,
                status,
                DATE_FORMAT(created_at, '%Y-%m-%d %H:%i:%s') as created_at
            FROM orders 
            WHERE user_id = ?
            ORDER BY created_at DESC
        ");
        
        $stmt->execute([$user_id]);
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch(PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage(),
            'orders' => []
        ]);
        exit;
    }
}

// Get items for each order (same for both admin and user)
foreach ($orders as &$order) {
    $order_id = $order['id'];
    
    $stmt = $pdo->prepare("
        SELECT 
            oi.id,
            oi.menu_item_id,
            oi.quantity,
            oi.price,
            m.name as menu_item_name
        FROM order_items oi
        LEFT JOIN menu_items m ON oi.menu_item_id = m.id
        WHERE oi.order_id = ?
    ");
    
    $stmt->execute([$order_id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $order['items'] = $items;
}

// Send response
echo json_encode([
    'success' => true,
    'message' => $is_admin_request ? 'All orders loaded' : 'Orders loaded successfully',
    'orders' => $orders,
    'count' => count($orders)
]);
?>