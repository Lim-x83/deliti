<?php
// api/orders/get_order_details.php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

require_once '../config.php';

$data = json_decode(file_get_contents("php://input"), true);

// Log for debugging
error_log("=== GET ORDER DETAILS CALLED ===");
error_log("Request data: " . print_r($data, true));

if(empty($data['order_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Order ID is required'
    ]);
    exit;
}

$order_id = intval($data['order_id']);
error_log("Getting details for order ID: $order_id");

try {
    // First get the order information
    $stmt = $pdo->prepare("
        SELECT 
            o.id,
            o.user_id,
            o.total_price,
            o.status,
            DATE_FORMAT(o.created_at, '%Y-%m-%d %H:%i:%s') as created_at,
            u.name as user_name,
            u.email as user_email
        FROM orders o
        LEFT JOIN users u ON o.user_id = u.id
        WHERE o.id = ?
    ");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if(!$order) {
        echo json_encode([
            'success' => false,
            'message' => 'Order not found'
        ]);
        exit;
    }
    
    error_log("Found order: " . print_r($order, true));
    
    // Get all items in this order with full product details
    $stmt = $pdo->prepare("
        SELECT 
            oi.id,
            oi.menu_item_id,
            oi.quantity,
            oi.price,
            mi.name,
            mi.description,
            mi.category,
            mi.image_path,
            mi.calories,
            mi.protein,
            mi.carbs,
            mi.fat,
            ROUND(oi.price * oi.quantity, 2) as item_total
        FROM order_items oi 
        LEFT JOIN menu_items mi ON oi.menu_item_id = mi.id 
        WHERE oi.order_id = ?
        ORDER BY oi.id
    ");
    $stmt->execute([$order_id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    error_log("Found " . count($items) . " items in order");
    
    // Calculate total to verify
    $calculated_total = 0;
    foreach($items as $item) {
        $calculated_total += ($item['price'] * $item['quantity']);
    }
    
    echo json_encode([
        'success' => true,
        'order' => $order,
        'items' => $items,
        'summary' => [
            'item_count' => count($items),
            'calculated_total' => round($calculated_total, 2),
            'order_total' => $order['total_price']
        ],
        'message' => 'Order details loaded successfully'
    ]);
    
} catch(PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>