<?php
// api/orders/get_all_orders.php
require_once '../config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

try {
    // Get ALL orders for admin - using PDO
    $stmt = $pdo->prepare("
        SELECT 
            o.id,
            o.user_id,
            o.total_price,
            o.status,
            DATE_FORMAT(o.created_at, '%Y-%m-%d %H:%i:%s') as created_at,
            u.name as customer_name
        FROM orders o
        LEFT JOIN users u ON o.user_id = u.id
        ORDER BY o.created_at DESC
    ");
    
    $stmt->execute();
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get items for each order
    foreach ($orders as &$order) {
        $order_id = $order['id'];
        
        $items_stmt = $pdo->prepare("
            SELECT 
                oi.id,
                oi.menu_item_id,
                oi.quantity,
                oi.price,
                m.name as menu_item_name
            FROM order_items oi
            LEFT JOIN menu_items m ON oi.menu_item_id = m.id
            WHERE oi.order_id = ?
        ");
        
        $items_stmt->execute([$order_id]);
        $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $order['items'] = $items;
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'All orders loaded',
        'orders' => $orders
    ]);
    
} catch(Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage(),
        'orders' => []
    ]);
}
?>