<?php
// api/accounting/get_ap.php
require_once '../config.php';

try {
    // Get all accounts payable
    $stmt = $pdo->query("
        SELECT * FROM accounts_payable 
        ORDER BY 
            CASE status
                WHEN 'unpaid' THEN 1
                WHEN 'overdue' THEN 2
                WHEN 'partial' THEN 3
                WHEN 'paid' THEN 4
            END,
            tanggal_transaksi DESC
    ");
    
    $ap = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate totals
    $total_unpaid = 0;
    $total_partial = 0;
    $total_paid = 0;
    
    foreach($ap as $item) {
        $total = $item['harga'] * $item['jumlah_barang'];
        
        if($item['status'] == 'unpaid' || $item['status'] == 'overdue') {
            $total_unpaid += $total;
        } elseif($item['status'] == 'partial') {
            $total_partial += $total;
        } elseif($item['status'] == 'paid') {
            $total_paid += $total;
        }
    }
    
    echo json_encode([
        'success' => true,
        'data' => $ap,
        'total' => count($ap),
        'summary' => [
            'total_unpaid' => $total_unpaid,
            'total_partial' => $total_partial,
            'total_paid' => $total_paid,
            'total_all' => $total_unpaid + $total_partial + $total_paid
        ]
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error fetching accounts payable: ' . $e->getMessage(),
        'data' => [],
        'total' => 0,
        'summary' => [
            'total_unpaid' => 0,
            'total_partial' => 0,
            'total_paid' => 0,
            'total_all' => 0
        ]
    ]);
}
?>