<?php
require_once '../config.php';

$data = json_decode(file_get_contents("php://input"), true);

if(!empty($data['id']) && !empty($data['status'])) {
    try {
        $update_data = [
            'status' => $data['status'],
            'id' => $data['id']
        ];
        
        // If status is paid and tanggal_bayar is provided, update it
        if($data['status'] == 'paid' && !empty($data['tanggal_bayar'])) {
            $sql = "UPDATE accounts_payable SET status = ?, tanggal_bayar = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
            $update_data['tanggal_bayar'] = $data['tanggal_bayar'];
            $params = [$data['status'], $data['tanggal_bayar'], $data['id']];
        } 
        // If status is paid but no date, use current date
        elseif($data['status'] == 'paid') {
            $sql = "UPDATE accounts_payable SET status = ?, tanggal_bayar = CURRENT_DATE, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
            $params = [$data['status'], $data['id']];
        }
        // For other statuses
        else {
            $sql = "UPDATE accounts_payable SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
            $params = [$data['status'], $data['id']];
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        echo json_encode([
            'success' => true,
            'message' => 'Payment status updated successfully'
        ]);
        
    } catch(PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Error updating status: ' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'ID and status are required'
    ]);
}
?>