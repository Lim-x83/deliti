<?php
// deliti/api/accounting/add_ar.php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

require_once __DIR__ . '/../config.php';

$data = json_decode(file_get_contents("php://input"));

if (!empty($data->nama) && !empty($data->jumlah)) {
    try {
        $sql = "INSERT INTO accounts_receivable (nama, deskripsi, jumlah, tanggal) 
                VALUES (:nama, :deskripsi, :jumlah, :tanggal)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':nama' => $data->nama,
            ':deskripsi' => $data->deskripsi ?? '',
            ':jumlah' => floatval($data->jumlah),
            ':tanggal' => $data->tanggal ?? date('Y-m-d')
        ]);
        
        echo json_encode([
            'success' => true,
            'message' => 'AR data added successfully',
            'id' => $pdo->lastInsertId()
        ]);
        
    } catch(PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Missing required fields'
    ]);
}
?>