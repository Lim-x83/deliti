<?php
// deliti/api/accounting/get_ar.php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . '/../config.php';

try {
    $sql = "SELECT * FROM accounts_receivable ORDER BY tanggal DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    
    $ar_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $total = array_sum(array_column($ar_data, 'jumlah'));
    
    echo json_encode([
        'success' => true,
        'data' => $ar_data,
        'total' => $total,
        'count' => count($ar_data)
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>