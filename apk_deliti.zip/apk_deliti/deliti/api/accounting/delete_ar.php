<?php
// deliti/api/accounting/delete_ar.php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

require_once __DIR__ . '/../config.php';

$data = json_decode(file_get_contents("php://input"));

if (!empty($data->id)) {
    try {
        $sql = "DELETE FROM accounts_receivable WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':id' => intval($data->id)]);
        
        if ($stmt->rowCount() > 0) {
            echo json_encode([
                'success' => true,
                'message' => 'AR data deleted successfully'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'No data found with that ID'
            ]);
        }
        
    } catch(PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'ID is required'
    ]);
}
?>