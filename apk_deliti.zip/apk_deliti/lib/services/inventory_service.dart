import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/inventory_model.dart';
import 'config.dart';

class InventoryService {
  static const String baseUrl = Config.baseUrl;

  // Get all inventory items
  static Future<List<InventoryItem>> getInventory() async {
    print('🔄 [InventoryService] Getting inventory data...');
    
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/inventory/get_inventory.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({}),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        
        if (data['success'] == true) {
          List<InventoryItem> items = [];
          for (var item in data['data']) {
            items.add(InventoryItem.fromJson(item));
          }
          print('✅ [InventoryService] Loaded ${items.length} items');
          return items;
        } else {
          print('❌ [InventoryService] API error: ${data['message']}');
          return [];
        }
      } else {
        print('❌ [InventoryService] HTTP error: ${response.statusCode}');
        return [];
      }
    } catch (e) {
      print('❌ [InventoryService] Error: $e');
      return [];
    }
  }

  // Delete inventory item (will delete from all 3 tables)
  static Future<Map<String, dynamic>> deleteInventory(int id) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/inventory/delete_inventory.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': id}),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        return {'success': false, 'message': 'Server error: ${response.statusCode}'};
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // Update inventory quantity (optional - if you create update_inventory.php)
  static Future<Map<String, dynamic>> updateInventoryQuantity(int id, int newQuantity) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/inventory/update_inventory.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'id': id,
          'jumlah_barang': newQuantity,
        }),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        return {'success': false, 'message': 'Server error: ${response.statusCode}'};
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }
}