class Config {

  static const String baseUrl = "http://localhost/deliti/api";
  // static const String baseUrl = "https://delitigroupproject.wuaze.com/deliti/api";
  
  // Database Configuration (if needed)
  static const String dbHost = "localhost";
  static const String dbName = "deliti";
  static const String dbUser = "root";
  static const String dbPassword = "";
  
  // Timeouts
  static const Duration apiTimeout = Duration(seconds: 10);
  static const Duration uploadTimeout = Duration(seconds: 30);
  
  // Other App Constants
  static const String appName = "Deliti";
  static const String version = "v.1.2.5";
  
  // Validation Constants
  static const int minPasswordLength = 6;
  static const int maxNameLength = 50;
  static const int maxEmailLength = 100;
}