import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/article_model.dart';
import 'config.dart';

class ArticleService {
  static const String baseUrl = Config.baseUrl;

  // Get all articles
  static Future<List<Article>> getArticles() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/articles/get_articles.php'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true && data['data'] != null) {
          final articles = (data['data'] as List)
              .map((item) => Article.fromJson(item))
              .toList();
          return articles;
        }
      }
      return [];
    } catch (e) {
      print('Error getting articles: $e');
      return [];
    }
  }

  // Create new article
  static Future<Map<String, dynamic>> createArticle(Article article) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/articles/create_article.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(article.toJson()),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        return {'success': false, 'message': 'Server error'};
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // Update article
  static Future<Map<String, dynamic>> updateArticle(Article article) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/articles/update_article.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'id': article.id,
          ...article.toJson(),
        }),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        return {'success': false, 'message': 'Server error'};
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // Delete article
  static Future<Map<String, dynamic>> deleteArticle(int id) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/articles/delete_article.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': id}),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        return {'success': false, 'message': 'Server error'};
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }




}
