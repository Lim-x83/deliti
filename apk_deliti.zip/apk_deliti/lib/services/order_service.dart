// lib/services/order_service.dart - COMPLETE VERSION
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/order_model.dart';
import 'config.dart';

class OrderService {
  static const String baseUrl = Config.baseUrl;
  
  static Future<List<Order>> getOrdersByUser(int userId) async {
    print('🔄 [OrderService] Getting orders for user $userId');
    
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/orders/get_orders.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'user_id': userId}),
      ).timeout(const Duration(seconds: 10));
      
      print('📦 [OrderService] Response status: ${response.statusCode}');
      
      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        print('📦 [OrderService] API success: ${data['success']}');
        
        if (data['success'] == true) {
          final ordersJson = data['orders'] as List<dynamic>? ?? [];
          print('📦 [OrderService] Found ${ordersJson.length} orders in API');
          
          // Convert each JSON to Order object
          List<Order> orders = [];
          for (var json in ordersJson) {
            try {
              if (json is Map<String, dynamic>) {
                orders.add(Order.fromJson(json));
              } else {
                print('❌ [OrderService] Order data is not Map: $json');
              }
            } catch (e) {
              print('❌ [OrderService] Error parsing order: $e');
            }
          }
          
          print('✅ [OrderService] Successfully loaded ${orders.length} orders');
          return orders;
        } else {
          print('❌ [OrderService] API error: ${data['message']}');
          return [];
        }
      } else {
        print('❌ [OrderService] HTTP error: ${response.statusCode}');
        return [];
      }
    } catch (e) {
      print('❌ [OrderService] Network error: $e');
      return [];
    }
  }
  
  static Future<bool> cancelOrder(int orderId) async {
    print('🔄 [OrderService] Cancelling order $orderId');
    
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/orders/cancel_order.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'order_id': orderId}),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final success = data['success'] == true;
        print('📦 [OrderService] Cancel result: $success - ${data['message']}');
        return success;
      }
      print('❌ [OrderService] Cancel HTTP error: ${response.statusCode}');
      return false;
    } catch (e) {
      print('❌ [OrderService] Cancel network error: $e');
      return false;
    }
  }
  
  static Future<Map<String, dynamic>> getOrderDetails(int orderId) async {
    print('🔄 [OrderService] Getting details for order $orderId');
    
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/orders/get_order_details.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'order_id': orderId}),
      ).timeout(const Duration(seconds: 10));

      print('📦 [OrderService] Details response status: ${response.statusCode}');
      print('📦 [OrderService] Details response body: ${response.body.length > 500 ? response.body.substring(0, 500) + "..." : response.body}');
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        
        if (data['success'] == true) {
          print('✅ [OrderService] Successfully loaded order details');
          return {
            'success': true,
            'order': data['order'] ?? {},
            'items': data['items'] ?? [],
            'message': data['message'] ?? 'Details loaded'
          };
        } else {
          print('❌ [OrderService] Details API error: ${data['message']}');
          return {
            'success': false,
            'message': data['message'] ?? 'Failed to load details',
            'order': {},
            'items': []
          };
        }
      } else {
        print('❌ [OrderService] Details HTTP error: ${response.statusCode}');
        return {
          'success': false,
          'message': 'Server error: ${response.statusCode}',
          'order': {},
          'items': []
        };
      }
    } catch (e) {
      print('❌ [OrderService] Details network error: $e');
      return {
        'success': false,
        'message': 'Network error: $e',
        'order': {},
        'items': []
      };
    }
  }
}