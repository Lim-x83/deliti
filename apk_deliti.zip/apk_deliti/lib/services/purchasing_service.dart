import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/purchasing_model.dart';
import 'config.dart';

class PurchasingService {
  static const String baseUrl = Config.baseUrl;

  static Future<List<PurchasingItem>> getPurchasing() async {
    print('🔄 [PurchasingService] Getting purchasing data...');
    
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/purchasing/get_purchasing.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({}),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        
        if (data['success'] == true) {
          List<PurchasingItem> items = [];
          for (var item in data['data']) {
            items.add(PurchasingItem.fromJson(item));
          }
          print('✅ [PurchasingService] Loaded ${items.length} purchases');
          return items;
        } else {
          print('❌ [PurchasingService] API error: ${data['message']}');
          return [];
        }
      } else {
        print('❌ [PurchasingService] HTTP error: ${response.statusCode}');
        return [];
      }
    } catch (e) {
      print('❌ [PurchasingService] Error: $e');
      return [];
    }
  }

  static Future<Map<String, dynamic>> addPurchase({
    required String namaBarang,
    required int jumlahBarang,
    required String satuanKuantitas,
    required String lokasiBarang,
    required DateTime expiredDate,
    required double harga,
    required String vendor,
  }) async {
    print('🔄 [PurchasingService] Adding new purchase...');
    
    try {
      print('📤 [PurchasingService] Preparing request...');
      
      final Map<String, dynamic> requestBody = {
        'nama_barang': namaBarang,
        'jumlah_barang': jumlahBarang,
        'satuan_kuantitas': satuanKuantitas,
        'lokasi_barang': lokasiBarang,
        'expired_date': expiredDate.toIso8601String().split('T')[0],
        'harga': harga,
        'vendor': vendor,
      };
      
      print('📤 [PurchasingService] Request body: $requestBody');
      
      final response = await http.post(
        Uri.parse('$baseUrl/purchasing/add_purchasing.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(requestBody),
      ).timeout(const Duration(seconds: 30)); // Increased timeout
      
      print('📦 [PurchasingService] Response status: ${response.statusCode}');
      print('📦 [PurchasingService] Response body: ${response.body}');

      if (response.statusCode == 200) {
        final result = jsonDecode(response.body);
        print('✅ [PurchasingService] Add purchase result: $result');
        return result;
      } else {
        print('❌ [PurchasingService] HTTP error: ${response.statusCode}');
        return {'success': false, 'message': 'Server error: ${response.statusCode}'};
      }
    } catch (e) {
      print('❌ [PurchasingService] Exception: $e');
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  static Future<Map<String, dynamic>> deletePurchase(int id) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/purchasing/delete_purchasing.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': id}),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        return {'success': false, 'message': 'Server error: ${response.statusCode}'};
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }
}


// SQL CODE - Dont delete/change (it used to know the curent SQL)

// -- ============================================
// -- FIRST: DELETE EXISTING TABLES
// -- ============================================
// DROP TABLE IF EXISTS accounts_payable;
// DROP TABLE IF EXISTS inventory;
// DROP TABLE IF EXISTS purchasing;
// DROP VIEW IF EXISTS all_inventory_data;
// DROP PROCEDURE IF EXISTS create_new_purchase;
// DROP TRIGGER IF EXISTS auto_generate_kode_before_purchase;

// -- ============================================
// -- SIMPLE SOLUTION WITH UNLIMITED 'PUR' CODES
// -- ============================================

// -- 1. PURCHASING TABLE
// CREATE TABLE purchasing (
//     id INT PRIMARY KEY AUTO_INCREMENT,
//     nama_barang VARCHAR(255) NOT NULL,
//     kode VARCHAR(50) UNIQUE, -- Auto: PUR-1, PUR-2, PUR-1000, PUR-999999
//     jumlah_barang INT NOT NULL DEFAULT 0,
//     satuan_kuantitas VARCHAR(20) NOT NULL,
//     lokasi_barang VARCHAR(100),
//     expired_date DATE,
//     harga DECIMAL(15,2) NOT NULL,
//     vendor VARCHAR(255) NOT NULL,
//     tanggal_transaksi DATE DEFAULT CURRENT_DATE,
//     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
// );

// -- 2. INVENTORY TABLE
// CREATE TABLE inventory (
//     id INT PRIMARY KEY AUTO_INCREMENT,
//     nama_barang VARCHAR(255) NOT NULL,
//     kode VARCHAR(50) NOT NULL,
//     jumlah_barang INT NOT NULL DEFAULT 0,
//     satuan_kuantitas VARCHAR(20) NOT NULL,
//     lokasi_barang VARCHAR(100),
//     expired_date DATE,
//     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//     updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
// );

// -- 3. ACCOUNTS PAYABLE TABLE
// CREATE TABLE accounts_payable (
//     id INT PRIMARY KEY AUTO_INCREMENT,
//     nama_barang VARCHAR(255) NOT NULL,
//     kode VARCHAR(50) NOT NULL,
//     jumlah_barang INT NOT NULL DEFAULT 0,
//     satuan_kuantitas VARCHAR(20) NOT NULL,
//     lokasi_barang VARCHAR(100),
//     expired_date DATE,
//     harga DECIMAL(15,2) NOT NULL,
//     vendor VARCHAR(255) NOT NULL,
//     tanggal_transaksi DATE DEFAULT CURRENT_DATE,
//     status ENUM('unpaid', 'partial', 'paid', 'overdue') DEFAULT 'unpaid',
//     tanggal_bayar DATE,
//     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//     updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
// );

// -- ============================================
// -- TRIGGER: UNLIMITED CODE GENERATION
// -- ============================================
// DELIMITER $$

// CREATE TRIGGER auto_generate_kode_before_purchase
// BEFORE INSERT ON purchasing
// FOR EACH ROW
// BEGIN
//     DECLARE last_number BIGINT DEFAULT 0;
    
//     -- If user provides a code, use it
//     IF NEW.kode IS NOT NULL AND NEW.kode != '' THEN
//         SET NEW.kode = NEW.kode;
//     ELSE
//         -- Get the highest number after 'PUR-'
//         SELECT COALESCE(MAX(
//             CAST(SUBSTRING(kode, 5) AS UNSIGNED)
//         ), 0) INTO last_number
//         FROM purchasing 
//         WHERE kode LIKE 'PUR-%';
        
//         -- No padding, just sequential number = UNLIMITED!
//         -- PUR-1, PUR-2, PUR-100, PUR-1000, PUR-999999, PUR-1000000, etc.
//         SET NEW.kode = CONCAT('PUR-', (last_number + 1));
//     END IF;
// END$$

// DELIMITER ;

// -- ============================================
// -- TRIGGER: Auto-copy to inventory & accounts_payable
// -- ============================================
// DELIMITER $$

// CREATE TRIGGER after_purchasing_insert
// AFTER INSERT ON purchasing
// FOR EACH ROW
// BEGIN
//     -- Auto-insert into inventory
//     INSERT INTO inventory (
//         nama_barang, kode, jumlah_barang, satuan_kuantitas,
//         lokasi_barang, expired_date
//     ) VALUES (
//         NEW.nama_barang, NEW.kode, NEW.jumlah_barang, NEW.satuan_kuantitas,
//         NEW.lokasi_barang, NEW.expired_date
//     );
    
//     -- Auto-insert into accounts_payable
//     INSERT INTO accounts_payable (
//         nama_barang, kode, jumlah_barang, satuan_kuantitas,
//         lokasi_barang, expired_date, harga, vendor,
//         tanggal_transaksi, status
//     ) VALUES (
//         NEW.nama_barang, NEW.kode, NEW.jumlah_barang, NEW.satuan_kuantitas,
//         NEW.lokasi_barang, NEW.expired_date, NEW.harga, NEW.vendor,
//         NEW.tanggal_transaksi, 'unpaid'
//     );
// END$$

// DELIMITER ;

// -- ============================================
// -- PROCEDURE: Create all 3 records
// -- ============================================
// DELIMITER $$

// CREATE PROCEDURE create_new_purchase(
//     IN p_nama_barang VARCHAR(255),
//     IN p_jumlah_barang INT,
//     IN p_satuan_kuantitas VARCHAR(20),
//     IN p_lokasi_barang VARCHAR(100),
//     IN p_expired_date DATE,
//     IN p_harga DECIMAL(15,2),
//     IN p_vendor VARCHAR(255)
// )
// BEGIN
//     -- Insert into purchasing (trigger handles the rest)
//     INSERT INTO purchasing (
//         nama_barang, jumlah_barang, satuan_kuantitas,
//         lokasi_barang, expired_date, harga, vendor
//     ) VALUES (
//         p_nama_barang, p_jumlah_barang, p_satuan_kuantitas,
//         p_lokasi_barang, p_expired_date, p_harga, p_vendor
//     );
    
//     -- Return the generated code
//     SELECT CONCAT('Purchase created with code: ', 
//                   (SELECT kode FROM purchasing ORDER BY id DESC LIMIT 1)) as message;
// END$$

// DELIMITER ;

// -- ============================================
// -- TEST: Create sample purchases
// -- ============================================

// -- Method 1: Using the procedure
// CALL create_new_purchase('Beras Premium', 100, 'kg', 'Gudang A', '2024-12-31', 15000.00, 'Toko Jaya');
// CALL create_new_purchase('Minyak Goreng', 50, 'liter', 'Gudang B', '2025-06-30', 25000.00, 'CV Sejahtera');
// CALL create_new_purchase('Gula Pasir', 200, 'kg', 'Rak 5', '2026-01-15', 12000.00, 'Distributor Manis');

// -- Method 2: Direct insert
// INSERT INTO purchasing (nama_barang, jumlah_barang, satuan_kuantitas, lokasi_barang, expired_date, harga, vendor)
// VALUES ('Telur Ayam', 500, 'pcs', 'Cold Storage', '2024-02-28', 2800.00, 'Peternakan');

// -- Method 3: Test MANY purchases (simulate 20 more)
// DELIMITER $$

// CREATE PROCEDURE test_many_purchases(IN count INT)
// BEGIN
//     DECLARE i INT DEFAULT 1;
//     WHILE i <= count DO
//         INSERT INTO purchasing (nama_barang, jumlah_barang, satuan_kuantitas, lokasi_barang, expired_date, harga, vendor)
//         VALUES (CONCAT('Product Test ', i), 10, 'pcs', 'Test Location', '2024-12-31', 1000.00, 'Test Vendor');
//         SET i = i + 1;
//     END WHILE;
// END$$

// DELIMITER ;

// -- Uncomment to test 20 more purchases:
// -- CALL test_many_purchases(20);

// -- ============================================
// -- VIEW: See all data together
// -- ============================================
// CREATE VIEW all_inventory_data AS
// SELECT 
//     'Purchasing' as source_table,
//     id, nama_barang, kode, jumlah_barang, satuan_kuantitas,
//     lokasi_barang, expired_date, harga, vendor, tanggal_transaksi,
//     NULL as status, NULL as tanggal_bayar, created_at
// FROM purchasing

// UNION ALL

// SELECT 
//     'Inventory' as source_table,
//     id, nama_barang, kode, jumlah_barang, satuan_kuantitas,
//     lokasi_barang, expired_date, NULL as harga, NULL as vendor, NULL as tanggal_transaksi,
//     NULL as status, NULL as tanggal_bayar, created_at
// FROM inventory

// UNION ALL

// SELECT 
//     'Accounts Payable' as source_table,
//     id, nama_barang, kode, jumlah_barang, satuan_kuantitas,
//     lokasi_barang, expired_date, harga, vendor, tanggal_transaksi,
//     status, tanggal_bayar, created_at
// FROM accounts_payable;

// -- ============================================
// -- CHECK THE RESULTS
// -- ============================================

// -- See the unlimited codes (PUR-1, PUR-2, PUR-3, ... PUR-100, PUR-1000, etc.)
// SELECT 'Unlimited Codes Generated:' as info;
// SELECT kode, nama_barang, created_at FROM purchasing ORDER BY id;

// -- See all tables
// SELECT COUNT(*) as total_purchases FROM purchasing;
// SELECT COUNT(*) as total_inventory FROM inventory;
// SELECT COUNT(*) as total_accounts_payable FROM accounts_payable;

// -- See everything together
// SELECT * FROM all_inventory_data ORDER BY CAST(SUBSTRING(kode, 5) AS UNSIGNED), source_table;




