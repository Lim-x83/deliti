import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_profile.dart';
import 'api_service.dart';

class ProfileService {
  static Future<UserProfile?> getCurrentUserProfile() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userId = prefs.getInt('user_id');
      
      if (userId == null) return null;
      
      final result = await ApiService.getUserProfile(userId);
      if (result['success'] == true) {
        return UserProfile.fromJson(result['profile']);
      }
      return null;
    } catch (e) {
      print('❌ ProfileService Error: $e');
      return null;
    }
  }

  static Future<bool> updateProfile(Map<String, dynamic> profileData) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userId = prefs.getInt('user_id');
      
      if (userId == null) return false;
      
      final result = await ApiService.updateProfile(userId, profileData);
      return result['success'] == true;
    } catch (e) {
      print('❌ ProfileService Update Error: $e');
      return false;
    }
  }

  static Future<bool> uploadProfilePicture(String imagePath) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userId = prefs.getInt('user_id');
      
      if (userId == null) return false;
      
      final result = await ApiService.uploadProfilePicture(userId, imagePath);
      return result['success'] == true;
    } catch (e) {
      print('❌ ProfileService Upload Error: $e');
      return false;
    }
  }
}