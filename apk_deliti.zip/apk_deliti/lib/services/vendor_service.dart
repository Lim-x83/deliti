import 'dart:convert';
import 'package:http/http.dart' as http;
import '../services/api_service.dart';

class VendorService {
  static const String baseUrl = ApiService.baseUrl;
  
  // Get all vendors
  static Future<List<Map<String, dynamic>>> getVendors() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/vendors/get_vendors.php'),
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          return List<Map<String, dynamic>>.from(data['data'] ?? []);
        }
      }
      return [];
    } catch (e) {
      print('Error getting vendors: $e');
      return [];
    }
  }
  
  // Add new vendor
  static Future<Map<String, dynamic>> addVendor(Map<String, dynamic> vendorData) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/vendors/add_vendor.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(vendorData),
      );
      
      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return {'success': false, 'message': 'HTTP error'};
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }
  
  // Delete vendor
  static Future<Map<String, dynamic>> deleteVendor(int vendorId) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/vendors/delete_vendor.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'id': vendorId}),
      );
      
      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return {'success': false, 'message': 'HTTP error'};
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }
}