import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/ap_model.dart';
import 'config.dart';

class AccountingService {
  static const String baseUrl = Config.baseUrl;

  // Get all accounts payable
  static Future<Map<String, dynamic>> getAccountsPayable() async {
    print('🔄 [AccountingService] Getting accounts payable...');
    
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/accounting/get_ap.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({}),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        
        if (data['success'] == true) {
          List<AccountPayable> items = [];
          for (var item in data['data']) {
            items.add(AccountPayable.fromJson(item));
          }
          print('✅ [AccountingService] Loaded ${items.length} AP records');
          
          return {
            'success': true,
            'data': items,
            'summary': data['summary'],
          };
        } else {
          return {
            'success': false,
            'message': data['message'],
            'data': [],
            'summary': {
              'total_unpaid': 0,
              'total_partial': 0,
              'total_paid': 0,
              'total_all': 0,
            }
          };
        }
      } else {
        return {
          'success': false,
          'message': 'Server error: ${response.statusCode}',
          'data': [],
          'summary': {
            'total_unpaid': 0,
            'total_partial': 0,
            'total_paid': 0,
            'total_all': 0,
          }
        };
      }
    } catch (e) {
      print('❌ [AccountingService] Error: $e');
      return {
        'success': false,
        'message': 'Network error: $e',
        'data': [],
        'summary': {
          'total_unpaid': 0,
          'total_partial': 0,
          'total_paid': 0,
          'total_all': 0,
        }
      };
    }
  }

  // Delete accounts payable
  static Future<Map<String, dynamic>> deleteAccountPayable(int id) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/accounting/delete_ap.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': id}),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        return {'success': false, 'message': 'Server error: ${response.statusCode}'};
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // Update payment status (optional - if you create update_ap_status.php)
  static Future<Map<String, dynamic>> updatePaymentStatus({
    required int id,
    required String status,
    DateTime? tanggalBayar,
  }) async {
    try {
      Map<String, dynamic> body = {
        'id': id,
        'status': status,
      };
      
      if (tanggalBayar != null) {
        body['tanggal_bayar'] = tanggalBayar.toIso8601String().split('T')[0];
      }

      final response = await http.post(
        Uri.parse('$baseUrl/accounting/update_ap_status.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        return {'success': false, 'message': 'Server error: ${response.statusCode}'};
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }
}