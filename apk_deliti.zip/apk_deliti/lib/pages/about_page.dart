// lib/pages/about_page.dart
import 'package:flutter/material.dart';
import '../services/config.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // BACKGROUND GRADIENTS
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.topRight,
                  radius: 1.5,
                  colors: [
                    Color(0xFF1a1a2e),
                    Colors.black,
                  ],
                ),
              ),
            ),
          ),
          
          // ANIMATED PARTICLES BACKGROUND
          Positioned.fill(
            child: CustomPaint(
              painter: _ParticlePainter(),
            ),
          ),
          
          SingleChildScrollView(
            child: Column(
              children: [
                // HEADER SECTION
                Container(
                  padding: const EdgeInsets.only(top: 70, bottom: 40),
                  child: Column(
                    children: [
                      // VERSION BADGE
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.purple.shade800,
                              Colors.deepPurple.shade900,
                            ],
                          ),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.purple.withOpacity(0.4),
                              blurRadius: 15,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                        child: Text(
                          '${Config.version}',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 30),
                      
                      // LOGO CONTAINER
                      Container(
                        width: 180,
                        height: 180,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Colors.purple.shade800,
                              Colors.deepPurple.shade900,
                            ],
                          ),
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.purple.withOpacity(0.5),
                              blurRadius: 25,
                              spreadRadius: 5,
                            ),
                          ],
                        ),
                        child: Stack(
                          children: [
                            // GLOW EFFECT
                            Positioned.fill(
                              child: Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: RadialGradient(
                                    colors: [
                                      Colors.purple.withOpacity(0.3),
                                      Colors.transparent,
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            
                            // LOGO TEXT
                            Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'DELITI',
                                    style: TextStyle(
                                      fontSize: 32,
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                      letterSpacing: 4,
                                      shadows: [
                                        Shadow(
                                          blurRadius: 10,
                                          color: Colors.purple.shade300,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    'SYSTEM',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w300,
                                      color: Colors.purple.shade200,
                                      letterSpacing: 8,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // TAGLINE
                      Text(
                        'REIMAGINING RESTAURANT MANAGEMENT',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w300,
                          color: Colors.grey.shade400,
                          letterSpacing: 3,
                        ),
                      ),
                    ],
                  ),
                ),
                
                // CONTENT SECTIONS
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    children: [
                      // MISSION CARD
                      _buildGlassCard(
                        icon: Icons.rocket_launch,
                        title: 'OUR MISSION',
                        content: '?',
                        gradient: [
                          Colors.purple.shade900.withOpacity(0.8),
                          Colors.deepPurple.shade900.withOpacity(0.8),
                        ],
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // VISION CARD
                      _buildGlassCard(
                        icon: Icons.visibility,
                        title: 'OUR VISION',
                        content: '?',
                        gradient: [
                          Colors.blue.shade900.withOpacity(0.8),
                          Colors.indigo.shade900.withOpacity(0.8),
                        ],
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // TECHNOLOGY CARD
                      _buildGlassCard(
                        icon: Icons.code,
                        title: 'TECHNOLOGY',
                        content: '?',
                        gradient: [
                          Colors.teal.shade900.withOpacity(0.8),
                          Colors.cyan.shade900.withOpacity(0.8),
                        ],
                      ),
                      
                      const SizedBox(height: 30),
                      
                      // STATS SECTION
                      Container(
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.1),
                            width: 1,
                          ),
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Colors.black.withOpacity(0.7),
                              Colors.grey.shade900.withOpacity(0.7),
                            ],
                          ),
                        ),
                        child: Column(
                          children: [
                            Text(
                              '📊 SYSTEM OVERVIEW',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                letterSpacing: 2,
                              ),
                            ),
                            
                            const SizedBox(height: 24),
                            
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                _buildStatItem(
                                  value: '7',
                                  label: 'Modules',
                                  color: Colors.purple,
                                ),
                                _buildStatItem(
                                  value: '24/7',
                                  label: 'Uptime',
                                  color: Colors.green,
                                ),
                                _buildStatItem(
                                  value: '${Config.version}',
                                  label: 'Version',
                                  color: Colors.blue,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      
                      const SizedBox(height: 30),
                      
                      // CONTACT SECTION
                      Container(
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Colors.grey.shade900.withOpacity(0.8),
                              Colors.black.withOpacity(0.8),
                            ],
                          ),
                          border: Border.all(
                            color: Colors.grey.shade800,
                            width: 1,
                          ),
                        ),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.connect_without_contact,
                                  color: Colors.purple.shade300,
                                  size: 24,
                                ),
                                const SizedBox(width: 10),
                                Text(
                                  'CONNECT WITH US',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                    letterSpacing: 2,
                                  ),
                                ),
                              ],
                            ),
                            
                            const SizedBox(height: 24),
                            
                            _buildContactLine(
                              icon: Icons.email,
                              text: 'support@deliti.com',
                              color: Colors.red.shade300,
                            ),
                            
                            _buildContactLine(
                              icon: Icons.phone,
                              text: '+62 831 1228 0118',
                              color: Colors.green.shade300,
                            ),
                            
                            _buildContactLine(
                              icon: Icons.location_pin,
                              text: 'Medan, Indonesia',
                              color: Colors.blue.shade300,
                            ),
                            
                            const SizedBox(height: 20),
                            
                            // OPERATION HOURS
                            Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                color: Colors.black.withOpacity(0.5),
                                border: Border.all(
                                  color: Colors.grey.shade800,
                                ),
                              ),
                              child: Column(
                                children: [
                                  Text(
                                    '🕒 OPERATION HOURS',
                                    style: TextStyle(
                                      color: Colors.yellow.shade300,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    'Monday - Sunday: 9:00 AM - 9:00 PM',
                                    style: TextStyle(
                                      color: Colors.grey.shade300,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      const SizedBox(height: 40),
                      
                      // FOOTER
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          border: Border(
                            top: BorderSide(
                              color: Colors.grey.shade800,
                              width: 1,
                            ),
                          ),
                        ),
                        child: Column(
                          children: [
                            Text(
                              'DELITI RESTAURANT MANAGEMENT SYSTEM',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w300,
                                color: Colors.grey.shade500,
                                letterSpacing: 2,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            
                            const SizedBox(height: 8),
                            
                            Text(
                              '© 2024 • v1.2.4 • ALL SYSTEMS OPERATIONAL',
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w300,
                                color: Colors.grey.shade600,
                                letterSpacing: 1,
                              ),
                            ),
                            
                            const SizedBox(height: 4),
                            
                            // STATUS INDICATOR
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  width: 8,
                                  height: 8,
                                  decoration: BoxDecoration(
                                    color: Colors.green,
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.green.withOpacity(0.5),
                                        blurRadius: 8,
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  'SYSTEM STATUS: ONLINE',
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: Colors.green.shade300,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ],
            ),
          ),
          
          // BACK BUTTON
          Positioned(
            top: 40,
            left: 20,
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.black.withOpacity(0.5),
                border: Border.all(
                  color: Colors.white.withOpacity(0.2),
                ),
              ),
              child: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildGlassCard({
    required IconData icon,
    required String title,
    required String content,
    required List<Color> gradient,
  }) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.white.withOpacity(0.1),
          width: 1,
        ),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: gradient,
        ),
        boxShadow: [
          BoxShadow(
            color: gradient.first.withOpacity(0.3),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: Colors.white, size: 24),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 20),
          
          Text(
            content,
            style: TextStyle(
              fontSize: 14,
              height: 1.6,
              color: Colors.white.withOpacity(0.9),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildStatItem({
    required String value,
    required String label,
    required Color color,
  }) {
    return Column(
      children: [
        Container(
          width: 90,
          height: 90,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                color.withOpacity(0.3),
                color.withOpacity(0.1),
              ],
            ),
            border: Border.all(
              color: color.withOpacity(0.3),
              width: 1,
            ),
          ),
          child: Center(
            child: Text(
              value,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ),
        ),
        
        const SizedBox(height: 8),
        
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey.shade400,
            fontWeight: FontWeight.w300,
          ),
        ),
      ],
    );
  }
  
  Widget _buildContactLine({
    required IconData icon,
    required String text,
    required Color color,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: Colors.black.withOpacity(0.3),
        border: Border.all(
          color: Colors.grey.shade800,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: color, size: 18),
          ),
          
          const SizedBox(width: 16),
          
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: Colors.grey.shade300,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// PARTICLE BACKGROUND PAINTER
class _ParticlePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.03)
      ..style = PaintingStyle.fill;
    
    // Draw random particles
    final random = DateTime.now().millisecond % 100;
    for (int i = 0; i < 50; i++) {
      final x = (i * 37 + random) % size.width;
      final y = (i * 23 + random) % size.height;
      final radius = 1 + (i % 3).toDouble();
      
      canvas.drawCircle(
        Offset(x, y),
        radius,
        paint,
      );
    }
  }
  
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}