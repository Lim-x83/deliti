import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/vendor_service.dart';

class VendorPage extends StatefulWidget {
  final User? user;
  
  const VendorPage({Key? key, this.user}) : super(key: key);

  @override
  State<VendorPage> createState() => _VendorPageState();
}

class _VendorPageState extends State<VendorPage> {
  List<Map<String, dynamic>> _vendors = [];
  bool _isLoading = true;
  String _error = '';

  @override
  void initState() {
    super.initState();
    _loadVendors();
  }

  Future<void> _loadVendors() async {
    try {
      setState(() => _isLoading = true);
      final vendors = await VendorService.getVendors();
      setState(() {
        _vendors = vendors;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to load vendors: $e';
        _isLoading = false;
      });
    }
  }

  // Auto-generate vendor code
  String _generateVendorCode(String vendorName) {
    String prefix = vendorName.length >= 3 
        ? vendorName.substring(0, 3).toUpperCase()
        : vendorName.toUpperCase();
    
    List<int> existingNumbers = [];
    for (var vendor in _vendors) {
      String? code = vendor['kode_vendor']?.toString();
      if (code != null && code.startsWith(prefix)) {
        try {
          String numberPart = code.substring(prefix.length);
          int num = int.tryParse(numberPart) ?? 0;
          if (num > 0) existingNumbers.add(num);
        } catch (e) {}
      }
    }
    
    int nextNumber = existingNumbers.isNotEmpty 
        ? (existingNumbers.reduce((a, b) => a > b ? a : b) + 1)
        : 1;
    
    return '$prefix${nextNumber.toString().padLeft(3, '0')}';
  }

  // Add new vendor
  Future<void> _addNewVendor() async {
    final nameController = TextEditingController();
    final ownerController = TextEditingController();
    final phoneController = TextEditingController();
    final emailController = TextEditingController();

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('➕ Add New Vendor'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.blue[50],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.auto_awesome, size: 16, color: Colors.blue),
                    SizedBox(width: 8),
                    Text('Vendor code will be auto-generated',
                      style: TextStyle(color: Colors.blue, fontSize: 12)),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'Store Name*',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.store),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: ownerController,
                decoration: const InputDecoration(
                  labelText: 'Owner Name',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: phoneController,
                decoration: const InputDecoration(
                  labelText: 'Phone',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.phone),
                ),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: emailController,
                decoration: const InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.email),
                ),
                keyboardType: TextInputType.emailAddress,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (nameController.text.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Store name is required'),
                    backgroundColor: Colors.red,
                  ),
                );
                return;
              }

              final generatedCode = _generateVendorCode(nameController.text);
              
              try {
                final result = await VendorService.addVendor({
                  'kode_vendor': generatedCode,
                  'nama_toko': nameController.text,
                  'nama_pemilik': ownerController.text,
                  'telepon': phoneController.text,
                  'email': emailController.text,
                  'jenis_vendor': 'supplier',
                  'status': 'active',
                });
                
                Navigator.pop(context);
                
                if (result['success'] == true) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('✅ Vendor added: $generatedCode'),
                      backgroundColor: Colors.green,
                    ),
                  );
                  await _loadVendors();
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Failed: ${result['message']}'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              } catch (e) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Error: $e'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            child: const Text('Add Vendor'),
          ),
        ],
      ),
    );
  }

  // Delete vendor
  Future<void> _deleteVendor(int vendorId, String vendorName) async {
    bool confirm = await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Vendor'),
        content: Text('Are you sure you want to delete "$vendorName"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    ) ?? false;

    if (confirm) {
      try {
        final result = await VendorService.deleteVendor(vendorId);
        
        if (result['success'] == true) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('✅ Vendor deleted: $vendorName'),
              backgroundColor: Colors.green,
            ),
          );
          await _loadVendors();
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Failed: ${result['message']}'),
              backgroundColor: Colors.red,
            ),
          );
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  // Get status color
  Color _getStatusColor(String status) {
    switch (status) {
      case 'active': return Colors.green;
      case 'inactive': return Colors.orange;
      case 'blacklist': return Colors.red;
      default: return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(title: Text('Vendors')),
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (_error.isNotEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Vendors')),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Error: $_error'),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _loadVendors,
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Vendors'),
        backgroundColor: Colors.purple,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '🏪 Vendor Management',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text(
                  '${_vendors.length} vendors registered',
                  style: const TextStyle(color: Colors.grey),
                ),
              ],
            ),
          ),

          // Vendor Table
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey[300]!),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.vertical,
                    child: DataTable(
                      columnSpacing: 20,
                      horizontalMargin: 12,
                      columns: const [
                        DataColumn(label: SizedBox(width: 60, child: Text('No'))),
                        DataColumn(label: SizedBox(width: 100, child: Text('Code'))),
                        DataColumn(label: SizedBox(width: 150, child: Text('Store Name'))),
                        DataColumn(label: SizedBox(width: 120, child: Text('Owner'))),
                        DataColumn(label: SizedBox(width: 120, child: Text('Phone'))),
                        DataColumn(label: SizedBox(width: 100, child: Text('Status'))),
                        DataColumn(label: SizedBox(width: 80, child: Text('Actions'))),
                      ],
                      rows: List<DataRow>.generate(
                        _vendors.length,
                        (index) {
                          final vendor = _vendors[index];
                          
                          return DataRow(
                            cells: [
                              DataCell(Center(child: Text('${index + 1}'))),
                              DataCell(Text(
                                vendor['kode_vendor']?.toString() ?? '-',
                                style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.blue),
                              )),
                              DataCell(Text(vendor['nama_toko']?.toString() ?? 'Unknown')),
                              DataCell(Text(vendor['nama_pemilik']?.toString() ?? '-')),
                              DataCell(Text(vendor['telepon']?.toString() ?? '-')),
                              DataCell(
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: _getStatusColor(vendor['status']?.toString() ?? 'active').withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text(
                                    (vendor['status']?.toString() ?? 'active').toUpperCase(),
                                    style: TextStyle(
                                      color: _getStatusColor(vendor['status']?.toString() ?? 'active'),
                                      fontWeight: FontWeight.bold,
                                      fontSize: 11,
                                    ),
                                  ),
                                ),
                              ),
                              DataCell(
                                IconButton(
                                  icon: const Icon(Icons.delete, size: 18, color: Colors.red),
                                  onPressed: () {
                                    _deleteVendor(
                                      vendor['id'] ?? 0,
                                      vendor['nama_toko']?.toString() ?? 'Unknown',
                                    );
                                  },
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),

          // Add Button
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: Icon(Icons.add_business, color:  Colors.white,),
                label: Text('Add New Vendor', style: TextStyle(color: Colors.white),),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: Colors.purple,
                ),
                onPressed: _addNewVendor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}