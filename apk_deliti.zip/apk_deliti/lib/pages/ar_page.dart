// lib/pages/ar_page.dart
import 'package:flutter/material.dart';
import '../models/ar_model.dart';
import '../services/accounting_service.dart';

class ArPage extends StatefulWidget {
  const ArPage({Key? key}) : super(key: key);

  @override
  State<ArPage> createState() => _ArPageState();
}

class _ArPageState extends State<ArPage> {
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    // Simulate loading
    Future.delayed(const Duration(seconds: 1), () {
      setState(() => _isLoading = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('📥 Accounts Receivable (AR)'),
        backgroundColor: Colors.green[800],
        foregroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _buildUnderConstructionBody(),
    );
  }

  Widget _buildUnderConstructionBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Construction Icon
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              color: Colors.green[50],
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.construction,
              size: 60,
              color: Colors.green,
            ),
          ),
          
          const SizedBox(height: 32),
          
          // Title
          const Text(
            '🚧 Fixed Soon',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: Colors.green,
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Description
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              'Our Accounts Receivable system is currently being upgraded to work with the new inventory system.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[600],
              ),
            ),
          ),
          
          const SizedBox(height: 32),
          
          // Info Card
          Card(
            margin: const EdgeInsets.symmetric(horizontal: 32),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const Icon(
                    Icons.info_outline,
                    color: Colors.blue,
                    size: 32,
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'What\'s Changing?',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    '• AR will be linked to customer orders\n• Auto-generated from sales\n• Integrated payment tracking\n• Better reporting features',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[700],
                      height: 1.6,
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 32),
          
          // Back Button
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green[800],
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Text(
              'Back to Dashboard',
              style: TextStyle(
                fontSize: 16,
                color: Colors.white,
              ),
            ),
          ),
          
          const SizedBox(height: 20),
          
          // Additional Info
          Text(
            'Estimated completion: Next update',
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey[500],
            ),
          ),
        ],
      ),
    );
  }
}

// Keeping the old code below (commented) for future reference
/*
// Old AR Model code - kept for future implementation
class ArModel {
  final int id;
  final String nama;
  final String? deskripsi;
  final double jumlah;
  final DateTime tanggal;
  final DateTime createdAt;

  ArModel({
    required this.id,
    required this.nama,
    this.deskripsi,
    required this.jumlah,
    required this.tanggal,
    required this.createdAt,
  });

  factory ArModel.fromJson(Map<String, dynamic> json) {
    return ArModel(
      id: json['id'] ?? 0,
      nama: json['nama'] ?? '',
      deskripsi: json['deskripsi'],
      jumlah: double.parse(json['jumlah'].toString()),
      tanggal: DateTime.parse(json['tanggal']),
      createdAt: DateTime.parse(json['created_at']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nama': nama,
      'deskripsi': deskripsi,
      'jumlah': jumlah,
      'tanggal': tanggal.toIso8601String(),
    };
  }
}

// Old AR Service methods - kept for future implementation
Future<Map<String, dynamic>> getAR() async {
  // Implementation for future
  return {'success': false, 'message': 'Under construction'};
}

Future<Map<String, dynamic>> addAR({
  required String nama,
  required double jumlah,
  String? deskripsi,
  DateTime? tanggal,
}) async {
  // Implementation for future
  return {'success': false, 'message': 'Under construction'};
}

Future<Map<String, dynamic>> deleteAR(int id) async {
  // Implementation for future
  return {'success': false, 'message': 'Under construction'};
}
*/