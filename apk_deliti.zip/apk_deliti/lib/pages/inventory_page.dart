import 'package:flutter/material.dart';
import '../models/inventory_model.dart';
import '../services/inventory_service.dart';
import '../services/config.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class InventoryPage extends StatefulWidget {
  const InventoryPage({Key? key}) : super(key: key);

  @override
  State<InventoryPage> createState() => _InventoryPageState();
}

class _InventoryPageState extends State<InventoryPage> {
  List<InventoryItem> _inventoryList = [];
  bool _isLoading = true;
  String _error = '';

  @override
  void initState() {
    super.initState();
    _loadInventory();
  }

  Future<void> _loadInventory() async {
    try {
      setState(() {
        _isLoading = true;
        _error = '';
      });
      
      print('🔄 [_InventoryPageState] Loading inventory...');
      final items = await InventoryService.getInventory();
      
      setState(() {
        _inventoryList = items;
        _isLoading = false;
      });
      
      print('✅ [_InventoryPageState] Loaded ${items.length} items');
      
    } catch (e) {
      setState(() {
        _error = "Error: $e";
        _isLoading = false;
      });
      print('❌ [_InventoryPageState] Exception: $e');
    }
  }

  void _showDeleteDialog(int id, String namaBarang) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Delete Item"),
        content: Text("Delete '$namaBarang' from inventory?\n\nThis will also delete from Purchasing and Accounts Payable."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              final response = await InventoryService.deleteInventory(id);
              if (response['success'] == true) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("Item deleted successfully"),
                    backgroundColor: Colors.green,
                  ),
                );
                _loadInventory();
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text("Failed: ${response['message']}"),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            child: const Text("Delete", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  // NEW: Show edit dialog
  void _showEditDialog(InventoryItem item) {
    final TextEditingController namaController = TextEditingController(text: item.namaBarang);
    final TextEditingController kodeController = TextEditingController(text: item.kode);
    final TextEditingController jumlahController = TextEditingController(text: item.jumlahBarang.toString());
    final TextEditingController satuanController = TextEditingController(text: item.satuanKuantitas);
    final TextEditingController lokasiController = TextEditingController(text: item.lokasiBarang ?? '');
    final TextEditingController hargaController = TextEditingController(text: item.harga?.toString() ?? '');
    final TextEditingController vendorController = TextEditingController(text: item.vendor ?? '');
    
    // For date
    DateTime? selectedDate = item.expiredDate;
    
    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text("Edit Inventory Item"),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextFormField(
                      controller: namaController,
                      decoration: const InputDecoration(
                        labelText: 'Item Name *',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: kodeController,
                      decoration: const InputDecoration(
                        labelText: 'Item Code *',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: jumlahController,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              labelText: 'Quantity *',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextFormField(
                            controller: satuanController,
                            decoration: const InputDecoration(
                              labelText: 'Unit *',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: lokasiController,
                      decoration: const InputDecoration(
                        labelText: 'Location',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 10),
                    // Expiry Date Picker
                    InkWell(
                      onTap: () async {
                        final DateTime? pickedDate = await showDatePicker(
                          context: context,
                          initialDate: selectedDate ?? DateTime.now(),
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2100),
                        );
                        if (pickedDate != null) {
                          setState(() {
                            selectedDate = pickedDate;
                          });
                        }
                      },
                      child: InputDecorator(
                        decoration: const InputDecoration(
                          labelText: 'Expiry Date',
                          border: OutlineInputBorder(),
                        ),
                        child: Row(
                          children: [
                            Text(
                              selectedDate != null 
                                ? "${selectedDate!.day}/${selectedDate!.month}/${selectedDate!.year}"
                                : "Select date",
                              style: TextStyle(
                                color: selectedDate != null ? Colors.black : Colors.grey,
                              ),
                            ),
                            const Spacer(),
                            const Icon(Icons.calendar_today),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: hargaController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Price',
                        prefixText: 'Rp ',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: vendorController,
                      decoration: const InputDecoration(
                        labelText: 'Vendor',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Cancel"),
                ),
                ElevatedButton(
                  onPressed: () async {
                    // Validate required fields
                    if (namaController.text.isEmpty || 
                        kodeController.text.isEmpty || 
                        jumlahController.text.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Please fill required fields (*)")),
                      );
                      return;
                    }

                    // Prepare update data
                    final updateData = {
                      'id': item.id,
                      'nama_barang': namaController.text,
                      'kode': kodeController.text,
                      'jumlah_barang': int.tryParse(jumlahController.text) ?? item.jumlahBarang,
                      'satuan_kuantitas': satuanController.text,
                      'lokasi_barang': lokasiController.text.isNotEmpty ? lokasiController.text : null,
                      'expired_date': selectedDate?.toIso8601String().split('T')[0],
                      'harga': hargaController.text.isNotEmpty ? double.tryParse(hargaController.text) : null,
                      'vendor': vendorController.text.isNotEmpty ? vendorController.text : null,
                    };

                    // Call update API (you need to create this)
                    final response = await _updateInventory(updateData);
                    
                    if (response['success'] == true) {
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("Item updated successfully"),
                          backgroundColor: Colors.green,
                        ),
                      );
                      _loadInventory();
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text("Failed: ${response['message']}"),
                          backgroundColor: Colors.red,
                        ),
                      );
                    }
                  },
                  child: const Text("Save Changes"),
                ),
              ],
            );
          },
        );
      },
    );
  }

  // NEW: Update inventory method
  Future<Map<String, dynamic>> _updateInventory(Map<String, dynamic> data) async {
    try {
      final response = await http.post(
        Uri.parse('${Config.baseUrl}/inventory/update_inventory.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(data),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        return {'success': false, 'message': 'Server error: ${response.statusCode}'};
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  String _formatDate(DateTime? date) {
    if (date == null) return "N/A";
    return "${date.day}/${date.month}/${date.year}";
  }

  Color _getExpiryColor(DateTime? expiryDate) {
    if (expiryDate == null) return Colors.grey;
    
    final now = DateTime.now();
    final daysUntilExpiry = expiryDate.difference(now).inDays;
    
    if (daysUntilExpiry < 0) {
      return Colors.red; // Expired
    } else if (daysUntilExpiry <= 7) {
      return Colors.orange; // Expiring soon (1 week)
    } else if (daysUntilExpiry <= 30) {
      return Colors.yellow[700]!; // Expiring soon (1 month)
    } else {
      return Colors.green; // Good
    }
  }

  IconData _getExpiryIcon(DateTime? expiryDate) {
    if (expiryDate == null) return Icons.calendar_today;
    
    final now = DateTime.now();
    final daysUntilExpiry = expiryDate.difference(now).inDays;
    
    if (daysUntilExpiry < 0) {
      return Icons.warning; // Expired
    } else if (daysUntilExpiry <= 7) {
      return Icons.warning_amber; // Expiring soon
    } else {
      return Icons.calendar_today; // Good
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('📦 Inventory Management'),
        backgroundColor: Colors.blue[800],
        foregroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _buildBody(),
      floatingActionButton: FloatingActionButton(
        onPressed: _loadInventory,
        backgroundColor: Colors.blue[800],
        foregroundColor: Colors.white,
        child: const Icon(Icons.refresh),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 20),
            Text("Loading inventory data..."),
          ],
        ),
      );
    }

    if (_error.isNotEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 60, color: Colors.red),
            const SizedBox(height: 20),
            Text("Error: $_error", textAlign: TextAlign.center),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _loadInventory,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue[800],
              ),
              child: const Text("Try Again", style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        // Header with stats
        Card(
          margin: const EdgeInsets.all(16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                const Text(
                  'Inventory Summary',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: [
                        const Icon(Icons.inventory_2, color: Colors.blue, size: 32),
                        const SizedBox(height: 8),
                        Text(
                          '${_inventoryList.length}',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Text('Items'),
                      ],
                    ),
                    Column(
                      children: [
                        Icon(Icons.warning, color: _inventoryList.any((item) => 
                          item.expiredDate != null && 
                          item.expiredDate!.difference(DateTime.now()).inDays < 0
                        ) ? Colors.red : Colors.green, size: 32),
                        const SizedBox(height: 8),
                        Text(
                          '${_inventoryList.where((item) => 
                            item.expiredDate != null && 
                            item.expiredDate!.difference(DateTime.now()).inDays < 0
                          ).length}',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Text('Expired'),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),

        // Filter tabs
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Expanded(
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.filter_list, size: 16),
                        const SizedBox(width: 8),
                        const Text('Filter:'),
                        const SizedBox(width: 8),
                        DropdownButton<String>(
                          value: 'all',
                          items: const [
                            DropdownMenuItem(value: 'all', child: Text('All Items')),
                            DropdownMenuItem(value: 'expiring', child: Text('Expiring Soon')),
                            DropdownMenuItem(value: 'expired', child: Text('Expired')),
                          ],
                          onChanged: (value) {
                            // Add filter logic here
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),

        // List of items
        Expanded(
          child: _inventoryList.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.inventory_2, size: 80, color: Colors.grey),
                      SizedBox(height: 16),
                      Text(
                        'No inventory items',
                        style: TextStyle(fontSize: 18, color: Colors.grey),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Make a purchase to add items',
                        style: TextStyle(color: Colors.grey),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _inventoryList.length,
                  itemBuilder: (context, index) {
                    final item = _inventoryList[index];
                    return _buildInventoryCard(item);
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildInventoryCard(InventoryItem item) {
    final expiryColor = _getExpiryColor(item.expiredDate);
    final expiryIcon = _getExpiryIcon(item.expiredDate);
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    item.namaBarang,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Row(
                  children: [
                    // EDIT BUTTON
                    IconButton(
                      icon: const Icon(Icons.edit, color: Colors.blue),
                      onPressed: () => _showEditDialog(item),
                    ),
                    // DELETE BUTTON
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _showDeleteDialog(item.id, item.namaBarang),
                    ),
                  ],
                ),
              ],
            ),

            const SizedBox(height: 8),

            // Code and Vendor
            Row(
              children: [
                const Icon(Icons.tag, size: 16, color: Colors.grey),
                const SizedBox(width: 6),
                Text(
                  'Code: ${item.kode}',
                  style: const TextStyle(
                    fontWeight: FontWeight.w500,
                    color: Colors.blue,
                  ),
                ),
                if (item.vendor != null && item.vendor!.isNotEmpty) ...[
                  const Spacer(),
                  const Icon(Icons.store, size: 16, color: Colors.grey),
                  const SizedBox(width: 6),
                  Text(
                    item.vendor!,
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                ],
              ],
            ),

            const SizedBox(height: 8),

            // Quantity and Location
            Row(
              children: [
                const Icon(Icons.scale, size: 16, color: Colors.grey),
                const SizedBox(width: 6),
                Text(
                  '${item.jumlahBarang} ${item.satuanKuantitas}',
                  style: const TextStyle(
                    fontWeight: FontWeight.w500,
                  ),
                ),
                if (item.lokasiBarang != null && item.lokasiBarang!.isNotEmpty) ...[
                  const Spacer(),
                  const Icon(Icons.location_on, size: 16, color: Colors.grey),
                  const SizedBox(width: 6),
                  Text(
                    item.lokasiBarang!,
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                ],
              ],
            ),

            const SizedBox(height: 8),

            // Expiry Date with warning
            Row(
              children: [
                Icon(expiryIcon, size: 16, color: expiryColor),
                const SizedBox(width: 6),
                Text(
                  'Expires: ${_formatDate(item.expiredDate)}',
                  style: TextStyle(
                    color: expiryColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const Spacer(),
                if (item.harga != null) ...[
                  const Icon(Icons.attach_money, size: 16, color: Colors.green),
                  const SizedBox(width: 6),
                  Text(
                    'Rp ${item.harga!.toStringAsFixed(0).replaceAllMapped(
                      RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
                      (Match m) => '${m[1]}.',
                    )}',
                    style: const TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ],
            ),

            // Created at info
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.calendar_today, size: 14, color: Colors.grey),
                const SizedBox(width: 6),
                Text(
                  'Added: ${_formatDate(item.createdAt)}',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
                const Spacer(),
                if (item.updatedAt != item.createdAt) ...[
                  const Icon(Icons.edit, size: 14, color: Colors.grey),
                  const SizedBox(width: 6),
                  Text(
                    'Updated: ${_formatDate(item.updatedAt)}',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}
