import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/order_model.dart';

class OrderManagementPage extends StatefulWidget {
  const OrderManagementPage({Key? key}) : super(key: key);

  @override
  _OrderManagementPageState createState() => _OrderManagementPageState();
}

class _OrderManagementPageState extends State<OrderManagementPage> {
  List<Order> _orders = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadOrders();
  }

  Future<void> _loadOrders() async {
    try {
      final orders = await ApiService.getOrders();
      setState(() {
        _orders = orders;
        _isLoading = false;
      });
    } catch (e) {
      print('Error loading orders: $e');
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load orders')),
      );
    }
  }

  Future<void> _updateOrderStatus(int orderId, String newStatus) async {
    try {
      final apiService = ApiService();
      final success = await apiService.updateOrderStatus(orderId, newStatus);
      if (success) {
        setState(() {
          final index = _orders.indexWhere((order) => order.id == orderId);
          if (index != -1) {
            _orders[index] = _orders[index].copyWith(status: newStatus);
          }
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Order status updated to $newStatus')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to update status')),
        );
      }
    } catch (e) {
      print('Error updating order status: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  // Get possible next statuses
  List<String> _getStatusOptions(String currentStatus) {
    final allStatuses = [
      'pending',
      'preparing',
      'cooking',
      'ready',
      'delivering',
      'completed',
      'cancelled'
    ];

    // Don't allow changing completed or cancelled orders
    if (currentStatus == 'completed' || currentStatus == 'cancelled') {
      return [currentStatus]; // Only show current status
    }

    return allStatuses;
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'pending':
        return Colors.orange;
      case 'preparing':
        return Colors.blue;
      case 'cooking':
        return Colors.deepOrange;
      case 'ready':
        return Colors.green;
      case 'delivering':
        return Colors.purple;
      case 'completed':
        return Colors.green.shade800;
      case 'cancelled':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  String _getStatusDisplay(String status) {
    switch (status) {
      case 'pending':
        return 'Pending';
      case 'preparing':
        return 'Preparing';
      case 'cooking':
        return 'Cooking';
      case 'ready':
        return 'Ready';
      case 'delivering':
        return 'Delivering';
      case 'completed':
        return 'Completed';
      case 'cancelled':
        return 'Cancelled';
      default:
        return status;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Order Management'),
        backgroundColor: Colors.green[800],
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadOrders,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _orders.isEmpty
              ? const Center(child: Text('No orders found'))
              : ListView.builder(
                  padding: const EdgeInsets.all(8.0),
                  itemCount: _orders.length,
                  itemBuilder: (context, index) {
                    final order = _orders[index];
                    final statusOptions = _getStatusOptions(order.status);
                    
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Order header
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Order #${order.id}',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                                  ],
                                ),
                                Chip(
                                  label: Text(
                                    _getStatusDisplay(order.status),
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 12,
                                    ),
                                  ),
                                  backgroundColor: _getStatusColor(order.status),
                                ),
                              ],
                            ),
                            
                            const SizedBox(height: 12),
                            
                            // Order details
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Total: Rp ${order.totalPrice.toStringAsFixed(0)}',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14,
                                      ),
                                    ),
                                    Text(
                                      'Created: ${_formatDate(order.createdAt.toString())}',
                                      style: TextStyle(color: Colors.grey[600], fontSize: 12),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            
                            const SizedBox(height: 12),
                            
                            // Order items
                            if (order.items.isNotEmpty)
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Items:',
                                    style: TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  ...order.items.map((item) => 
                                    Padding(
                                      padding: const EdgeInsets.symmetric(vertical: 2.0),
                                      child: Text(
                                        '• ${item.menuItemName} x${item.quantity} - Rp ${(item.price * item.quantity).toStringAsFixed(0)}',
                                        style: TextStyle(fontSize: 13),
                                      ),
                                    )
                                  ).toList(),
                                ],
                              ),
                            
                            const SizedBox(height: 16),
                            
                            // Status dropdown
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.grey[100],
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: Colors.grey[300]!),
                              ),
                              child: Row(
                                children: [
                                  const Icon(Icons.edit, size: 18, color: Colors.grey),
                                  const SizedBox(width: 8),
                                  const Text(
                                    'Change Status:',
                                    style: TextStyle(fontSize: 13, color: Colors.grey),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: DropdownButtonHideUnderline(
                                      child: DropdownButton<String>(
                                        value: order.status,
                                        isExpanded: true,
                                        icon: const Icon(Icons.arrow_drop_down, size: 20),
                                        style: TextStyle(
                                          color: _getStatusColor(order.status),
                                          fontWeight: FontWeight.bold,
                                          fontSize: 13,
                                        ),
                                        items: statusOptions.map((String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Row(
                                              children: [
                                                Container(
                                                  width: 10,
                                                  height: 10,
                                                  decoration: BoxDecoration(
                                                    color: _getStatusColor(value),
                                                    shape: BoxShape.circle,
                                                  ),
                                                ),
                                                const SizedBox(width: 8),
                                                Text(_getStatusDisplay(value)),
                                              ],
                                            ),
                                          );
                                        }).toList(),
                                        onChanged: (order.status == 'completed' || order.status == 'cancelled')
                                            ? null // Disable for completed/cancelled
                                            : (String? newValue) {
                                                if (newValue != null && newValue != order.status) {
                                                  _updateOrderStatus(order.id, newValue);
                                                }
                                              },
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            
                            // Note for completed/cancelled orders
                            if (order.status == 'completed' || order.status == 'cancelled')
                              Padding(
                                padding: const EdgeInsets.only(top: 8.0),
                                child: Text(
                                  order.status == 'completed' 
                                    ? '✅ This order has been completed' 
                                    : '❌ This order has been cancelled',
                                  style: TextStyle(
                                    color: order.status == 'completed' ? Colors.green : Colors.red,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }

  String _formatDate(String? dateString) {
    if (dateString == null) return 'Unknown date';
    try {
      final date = DateTime.parse(dateString);
      return '${date.day}/${date.month}/${date.year} ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
    } catch (e) {
      return dateString;
    }
  }
}