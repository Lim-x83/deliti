import 'package:flutter/material.dart';
import '../services/accounting_service.dart';
import '../models/ap_model.dart';

class ApPage extends StatefulWidget {
  const ApPage({Key? key}) : super(key: key);

  @override
  State<ApPage> createState() => _ApPageState();
}

class _ApPageState extends State<ApPage> {
  List<AccountPayable> _apList = [];
  bool _isLoading = true;
  String _error = '';
  double _totalUnpaid = 0.0;
  double _totalPaid = 0.0;

  @override
  void initState() {  
    super.initState();
    _loadAP();
  }

  Future<void> _loadAP() async {
    try {
      setState(() {
        _isLoading = true;
        _error = '';
        _totalUnpaid = 0.0;
        _totalPaid = 0.0;
      });
      
      print('🔄 Loading accounts payable...');
      final response = await AccountingService.getAccountsPayable();
      
      if (response['success'] == true && response['data'] != null) {
        final data = response['data'] as List<dynamic>;
        
        // Convert each item to AccountPayable object
        final apList = data.map((item) {
          if (item is AccountPayable) {
            return item;
          } else if (item is Map<String, dynamic>) {
            return AccountPayable.fromJson(item);
          } else {
            return AccountPayable(
              id: 0,
              namaBarang: 'Unknown',
              kode: 'N/A',
              jumlahBarang: 0,
              satuanKuantitas: 'pcs',
              harga: 0.0,
              vendor: 'Unknown',
              tanggalTransaksi: DateTime.now(),
              status: 'unpaid',
              createdAt: DateTime.now(),
              updatedAt: DateTime.now(),
            );
          }
        }).toList();
        
        // Calculate totals
        double unpaidTotal = 0.0;
        double paidTotal = 0.0;
        
        for (var ap in apList) {
          if (ap.isPaid) {
            paidTotal += ap.totalHarga;
          } else {
            unpaidTotal += ap.totalHarga;
          }
        }
        
        setState(() {
          _apList = apList;
          _totalUnpaid = unpaidTotal;
          _totalPaid = paidTotal;
          _isLoading = false;
        });
        
        print('✅ Loaded ${_apList.length} AP records');
      } else {
        setState(() {
          _error = response['message'] ?? "Failed to load accounts payable";
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = "Error: ${e.toString()}";
        _isLoading = false;
      });
      print('❌ Error in _loadAP: $e');
    }
  }

  Future<void> _updateStatus(AccountPayable ap, String newStatus) async {
    try {
      final response = await AccountingService.updatePaymentStatus(
        id: ap.id,
        status: newStatus,
        tanggalBayar: newStatus == 'paid' ? DateTime.now() : null,
      );

      if (response['success'] == true) {
        // Update local state
        setState(() {
          final index = _apList.indexWhere((item) => item.id == ap.id);
          if (index != -1) {
            _apList[index] = ap.copyWith(
              status: newStatus,
              tanggalBayar: newStatus == 'paid' ? DateTime.now() : null,
            );
          }
        });

        // Recalculate totals
        double unpaidTotal = 0.0;
        double paidTotal = 0.0;
        
        for (var item in _apList) {
          if (item.isPaid) {
            paidTotal += item.totalHarga;
          } else {
            unpaidTotal += item.totalHarga;
          }
        }
        
        setState(() {
          _totalUnpaid = unpaidTotal;
          _totalPaid = paidTotal;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Payment status updated to $newStatus'),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed: ${response['message']}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  String _formatCurrency(double amount) {
    if (amount == 0) return "Rp 0";
    return 'Rp ${amount.toStringAsFixed(0).replaceAllMapped(
      RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
      (Match m) => '${m[1]}.',
    )}';
  }

  String _formatDate(DateTime? date) {
    if (date == null) return "N/A";
    return "${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}";
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'unpaid':
        return Colors.red;
      case 'overdue':
        return Colors.deepOrange;
      case 'partial':
        return Colors.orange;
      case 'paid':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  String _getStatusText(String status) {
    switch (status) {
      case 'unpaid':
        return 'UNPAID';
      case 'overdue':
        return 'OVERDUE';
      case 'partial':
        return 'PARTIAL';
      case 'paid':
        return 'PAID';
      default:
        return status.toUpperCase();
    }
  }

  // Helper to get next status options
  List<String> _getNextStatusOptions(String currentStatus) {
    switch (currentStatus) {
      case 'unpaid':
        return ['partial', 'paid'];
      case 'partial':
        return ['paid'];
      case 'overdue':
        return ['partial', 'paid'];
      case 'paid':
        return []; // No further changes
      default:
        return ['partial', 'paid'];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('📤 Accounts Payable'),
        backgroundColor: Colors.red[800],
        foregroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _buildBody(),
      floatingActionButton: FloatingActionButton(
        onPressed: _loadAP,
        backgroundColor: Colors.red[800],
        foregroundColor: Colors.white,
        child: const Icon(Icons.refresh),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 20),
            Text("Loading accounts payable..."),
          ],
        ),
      );
    }

    if (_error.isNotEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 60, color: Colors.red),
              const SizedBox(height: 20),
              Text("Error", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.red[800])),
              const SizedBox(height: 10),
              Text(_error, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, color: Colors.grey)),
              const SizedBox(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey[600],
                      padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.arrow_back, color: Colors.white, size: 20),
                        SizedBox(width: 8),
                        Text("Go Back", style: TextStyle(color: Colors.white, fontSize: 16)),
                      ],
                    ),
                  ),
                  const SizedBox(width: 20),
                  ElevatedButton(
                    onPressed: _loadAP,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red[800],
                      padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.refresh, color: Colors.white, size: 20),
                        SizedBox(width: 8),
                        Text("Try Again", style: TextStyle(color: Colors.white, fontSize: 16)),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    }

    return Column(
      children: [
        // Summary Cards
        Container(
          padding: const EdgeInsets.all(16),
          color: Colors.grey[50],
          child: Row(
            children: [
              Expanded(
                child: Card(
                  color: Colors.red[50],
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        const Text('UNPAID', style: TextStyle(fontSize: 14, color: Colors.red, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        Text(_formatCurrency(_totalUnpaid), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.red)),
                        const SizedBox(height: 4),
                        Text('${_apList.where((ap) => ap.isUnpaid).length} items', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Card(
                  color: Colors.green[50],
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        const Text('PAID', style: TextStyle(fontSize: 14, color: Colors.green, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        Text(_formatCurrency(_totalPaid), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.green)),
                        const SizedBox(height: 4),
                        Text('${_apList.where((ap) => ap.isPaid).length} items', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),

        // Total Items
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          color: Colors.blue[50],
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Total Records:', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
              Chip(
                backgroundColor: Colors.blue[100],
                label: Text('${_apList.length} items', style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),

        // Info Note
        Container(
          padding: const EdgeInsets.all(16),
          color: Colors.orange[50],
          child: const Row(
            children: [
              Icon(Icons.info_outline, color: Colors.orange, size: 20),
              SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Click on payment status to update (unpaid → partial → paid)',
                  style: TextStyle(color: Colors.orange),
                ),
              ),
            ],
          ),
        ),

        // List of AP items
        Expanded(
          child: _apList.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.shopping_cart_outlined, size: 80, color: Colors.grey[400]),
                      const SizedBox(height: 16),
                      const Text('No accounts payable records', style: TextStyle(fontSize: 18, color: Colors.grey)),
                      const SizedBox(height: 8),
                      const Text('Make a purchase to see AP records here', style: TextStyle(color: Colors.grey)),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: () => Navigator.pop(context),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red[800],
                          padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                        ),
                        child: const Text('Go Back', style: TextStyle(color: Colors.white)),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: _apList.length,
                  itemBuilder: (context, index) {
                    return _buildAPCard(_apList[index], index);
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildAPCard(AccountPayable ap, int index) {
    final statusColor = _getStatusColor(ap.status);
    final daysRemaining = ap.expiredDate != null
        ? ap.expiredDate!.difference(DateTime.now()).inDays
        : null;
    final nextStatusOptions = _getNextStatusOptions(ap.status);

    return Card(
      margin: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with Code and Status
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.blue[50],
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: Colors.blue[100]!),
                  ),
                  child: Text(ap.kode, style: const TextStyle(color: Colors.blue, fontWeight: FontWeight.bold, fontSize: 12)),
                ),
                const Spacer(),
                // Status button (clickable if not paid)
                InkWell(
                  onTap: ap.status != 'paid' && nextStatusOptions.isNotEmpty
                      ? () => _showStatusMenu(ap)
                      : null,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: statusColor),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(_getStatusText(ap.status), style: TextStyle(color: statusColor, fontWeight: FontWeight.bold, fontSize: 11)),
                        if (ap.status != 'paid' && nextStatusOptions.isNotEmpty)
                          const Icon(Icons.arrow_drop_down, size: 16, color: Colors.grey),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            // Product Name
            Text(ap.namaBarang, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold), maxLines: 2, overflow: TextOverflow.ellipsis),

            const SizedBox(height: 8),

            // Vendor
            Row(
              children: [
                Icon(Icons.store, size: 16, color: Colors.grey[600]),
                const SizedBox(width: 6),
                Expanded(child: Text(ap.vendor, style: TextStyle(color: Colors.grey[600]), overflow: TextOverflow.ellipsis)),
              ],
            ),

            const SizedBox(height: 8),

            // Quantity and Price per unit
            Row(
              children: [
                const Icon(Icons.scale, size: 16, color: Colors.grey),
                const SizedBox(width: 6),
                Text('${ap.jumlahBarang} ${ap.satuanKuantitas}', style: const TextStyle(fontWeight: FontWeight.w500)),
                const Spacer(),
                Icon(Icons.attach_money, size: 16, color: Colors.green[700]),
                const SizedBox(width: 4),
                Text(_formatCurrency(ap.harga), style: TextStyle(color: Colors.green[700], fontWeight: FontWeight.w500)),
                const SizedBox(width: 4),
                Text('/${ap.satuanKuantitas}', style: const TextStyle(color: Colors.grey)),
              ],
            ),

            const SizedBox(height: 12),

            // Total Price
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.red[50], borderRadius: BorderRadius.circular(8)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('TOTAL:', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red)),
                  Text(_formatCurrency(ap.totalHarga), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.red)),
                ],
              ),
            ),

            const SizedBox(height: 12),

            // Payment Status Buttons (if not paid)
            if (nextStatusOptions.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.grey[50], borderRadius: BorderRadius.circular(8)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Update Payment:', style: TextStyle(fontSize: 12, color: Colors.grey, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: nextStatusOptions.map((status) {
                        return ElevatedButton(
                          onPressed: () => _updateStatus(ap, status),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _getStatusColor(status),
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                          ),
                          child: Text(
                            status.toUpperCase(),
                            style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),

            const SizedBox(height: 12),

            // Dates Information
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.calendar_today, size: 16, color: Colors.grey[600]),
                    const SizedBox(width: 6),
                    Text('Transaction: ${_formatDate(ap.tanggalTransaksi)}', style: TextStyle(color: Colors.grey[600])),
                  ],
                ),

                if (ap.expiredDate != null) ...[
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(Icons.warning, size: 16, color: daysRemaining != null && daysRemaining < 0 ? Colors.red : Colors.orange),
                      const SizedBox(width: 6),
                      Text('Expires: ${_formatDate(ap.expiredDate)}', style: TextStyle(
                        color: daysRemaining != null && daysRemaining < 0 ? Colors.red : Colors.orange,
                        fontWeight: daysRemaining != null && daysRemaining < 0 ? FontWeight.bold : FontWeight.normal,
                      )),
                      if (daysRemaining != null && daysRemaining < 0) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(4)),
                          child: const Text('OVERDUE', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ],
                  ),
                ],

                if (ap.tanggalBayar != null) ...[
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(Icons.payment, size: 16, color: Colors.green),
                      const SizedBox(width: 6),
                      Text('Paid on: ${_formatDate(ap.tanggalBayar)}', style: const TextStyle(color: Colors.green)),
                    ],
                  ),
                ],
              ],
            ),

            // Location (if available)
            if (ap.lokasiBarang != null && ap.lokasiBarang!.isNotEmpty) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  Icon(Icons.location_on, size: 16, color: Colors.blue),
                  const SizedBox(width: 6),
                  Text('Location: ${ap.lokasiBarang}', style: const TextStyle(color: Colors.blue)),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _showStatusMenu(AccountPayable ap) {
    final nextStatusOptions = _getNextStatusOptions(ap.status);
    
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Update Payment Status', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              Text('Item: ${ap.namaBarang}', style: const TextStyle(fontSize: 14)),
              Text('Amount: ${_formatCurrency(ap.totalHarga)}', style: const TextStyle(fontSize: 14)),
              const SizedBox(height: 20),
              ...nextStatusOptions.map((status) {
                return ListTile(
                  leading: Icon(Icons.payment, color: _getStatusColor(status)),
                  title: Text(status.toUpperCase(), style: TextStyle(color: _getStatusColor(status), fontWeight: FontWeight.bold)),
                  subtitle: Text(status == 'paid' ? 'Mark as fully paid' : 'Mark as partially paid'),
                  onTap: () {
                    Navigator.pop(context);
                    _updateStatus(ap, status);
                  },
                );
              }).toList(),
              const SizedBox(height: 20),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel'),
              ),
            ],
          ),
        );
      },
    );
  }
}

extension AccountPayableCopyWith on AccountPayable {
  AccountPayable copyWith({
    int? id,
    String? namaBarang,
    String? kode,
    int? jumlahBarang,
    String? satuanKuantitas,
    String? lokasiBarang,
    DateTime? expiredDate,
    double? harga,
    String? vendor,
    DateTime? tanggalTransaksi,
    String? status,
    DateTime? tanggalBayar,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return AccountPayable(
      id: id ?? this.id,
      namaBarang: namaBarang ?? this.namaBarang,
      kode: kode ?? this.kode,
      jumlahBarang: jumlahBarang ?? this.jumlahBarang,
      satuanKuantitas: satuanKuantitas ?? this.satuanKuantitas,
      lokasiBarang: lokasiBarang ?? this.lokasiBarang,
      expiredDate: expiredDate ?? this.expiredDate,
      harga: harga ?? this.harga,
      vendor: vendor ?? this.vendor,
      tanggalTransaksi: tanggalTransaksi ?? this.tanggalTransaksi,
      status: status ?? this.status,
      tanggalBayar: tanggalBayar ?? this.tanggalBayar,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}