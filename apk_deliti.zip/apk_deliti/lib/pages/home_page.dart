import 'package:apk_deliti/pages/articles_page.dart';
import 'package:flutter/material.dart';
import 'package:apk_deliti/pages/inventory_page.dart';
import 'package:apk_deliti/pages/report_page.dart';
import '../services/cart_service.dart';
import '../themes/app_theme.dart';
import '../models/user_model.dart';
import 'login_page.dart';
import 'menu_page.dart';
import 'cart_page.dart';
import 'profile_page.dart';
import 'about_page.dart';
import 'admin_dashboard_page.dart';
import 'orders_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class MenuAction {
  final String label;
  final IconData icon;
  final VoidCallback action;
  final bool requiresLogin;
  final bool requiresAdmin;
  final bool requiresLogout;
  final Color? color;

  const MenuAction({
    required this.label,
    required this.icon,
    required this.action,
    this.requiresLogin = false,
    this.requiresAdmin = false,
    this.requiresLogout = false,
    this.color,
  });
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;
  final CartService cartService = CartService();
  User? _currentUser;

  // ========== RESPONSIVE LAYOUT HELPERS ==========
  bool get isDesktop => MediaQuery.of(context).size.width >= 1024;
  bool get isTablet => MediaQuery.of(context).size.width >= 600;
  bool get isMobile => !isTablet;

  // ========== MENU MANAGEMENT ==========
  Map<String, MenuAction> _getMenuActions() {
    return {
      'profile': MenuAction(
        label: 'My Profile',
        icon: Icons.person,
        action: () {
          if (_currentUser != null) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ProfilePage(currentUser: _currentUser!),
              ),
            );
          }
        },
        requiresLogin: true,
      ),
      'orders': MenuAction(
        label: 'My Orders',
        icon: Icons.receipt_long,
        action: () {
          if (_currentUser != null) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => OrdersPage(currentUser: _currentUser!),
              ),
            );
          }
        },
        requiresLogin: true,
      ),
      'artikel': MenuAction(
        label: 'Artikel',
        icon: Icons.article,
        action: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ArticlesPage()),
          );
        },
      ),
      'about': MenuAction(
        label: 'About Deliti',
        icon: Icons.info_outline,
        action: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AboutPage()),
          );
        },
      ),
      'report': MenuAction(
        label: 'Report',
        icon: Icons.report_problem,
        action: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ReportPage()),
          );
        },
      ),
      'admin_dashboard': MenuAction(
        label: 'Admin Dashboard',
        icon: Icons.admin_panel_settings,
        action: () {
          if (_currentUser != null && _currentUser!.isAdmin) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AdminDashboardPage(user: _currentUser!),
              ),
            );
          }
        },
        requiresAdmin: true,
        color: Colors.purple,
      ),
      'inventory': MenuAction(
        label: 'Inventory',
        icon: Icons.inventory_2,
        action: () {
          if (_currentUser != null && _currentUser!.isAdmin) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => InventoryPage(),
              ),
            );
          }
        },
        requiresAdmin: true,
        color: Colors.blue,
      ),
      'login': MenuAction(
        label: 'Login',
        icon: Icons.login,
        action: _navigateToLogin,
        requiresLogout: true,
      ),
      'logout': MenuAction(
        label: 'Logout',
        icon: Icons.logout,
        action: _logout,
        requiresLogin: true,
      ),
    };
  }

  List<PopupMenuEntry<String>> _buildMenuItems() {
    final actions = _getMenuActions();
    final items = <PopupMenuEntry<String>>[];

    if (_currentUser != null) {
      items.addAll([
        _buildMenuItem('profile', actions['profile']!),
        _buildMenuItem('orders', actions['orders']!),
        const PopupMenuDivider(),
      ]);
    }

    items.addAll([
      _buildMenuItem('artikel', actions['artikel']!),
      _buildMenuItem('about', actions['about']!),
      _buildMenuItem('report', actions['report']!),
    ]);

    if (_currentUser != null && _currentUser!.isAdmin) {
      items.addAll([
        const PopupMenuDivider(),
        _buildMenuItem('admin_dashboard', actions['admin_dashboard']!),
        _buildMenuItem('inventory', actions['inventory']!),
      ]);
    }

    final authKey = _currentUser != null ? 'logout' : 'login';
    items.add(_buildMenuItem(authKey, actions[authKey]!));

    return items;
  }

  PopupMenuItem<String> _buildMenuItem(String key, MenuAction action) {
    return PopupMenuItem<String>(
      value: key,
      child: Row(
        children: [
          Icon(action.icon, size: 20, color: action.color),
          const SizedBox(width: 8),
          Text(
            action.label,
            style: TextStyle(
              color: action.color,
              fontWeight: action.requiresAdmin ? FontWeight.bold : null,
            ),
          ),
        ],
      ),
    );
  }

  void _showMainMenu() {
    final items = _buildMenuItems();

    showMenu<String>(
      context: context,
      position: const RelativeRect.fromLTRB(100, 80, 0, 0),
      items: items,
    ).then((value) {
      if (value != null) {
        _getMenuActions()[value]?.action();
      }
    });
  }

  // ========== AUTH METHODS ==========
  void _navigateToLogin() async {
    final user = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => LoginPage()),
    );
    if (user != null) {
      setState(() => _currentUser = user);
      await cartService.setUser(user);
      setState(() {});
    }
  }

  void _logout() {
    setState(() {
      _currentUser = null;
      cartService.clearUser();
      cartService.clearCart();
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Logged out successfully'),
        backgroundColor: Colors.green,
      ),
    );
  }

  // ========== MAIN BUILD ==========
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: _buildAppBar(),
      body: _buildBody(),
      bottomNavigationBar: isDesktop ? null : _buildBottomNavBar(),
    );
  }

  // ========== RESPONSIVE APP BAR ==========
  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.black,
      foregroundColor: Colors.white,
      title: Row(
        children: [
          // Logo/Brand area
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: AppTheme.primaryColor,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Text(
              'DELITI',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.2,
              ),
            ),
          ),
          const SizedBox(width: 8),
          // Show navigation tabs on desktop
          if (isDesktop) _buildDesktopNavigation(),
          const Spacer(),
          // Cart indicator on desktop
          if (isDesktop) _buildCartIndicator(),
        ],
      ),
      actions: [
        if (!isDesktop) // Only show menu button on mobile/tablet
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: _showMainMenu,
          ),
        if (isDesktop) _buildDesktopMenu(),
      ],
    );
  }

  // ========== DESKTOP NAVIGATION ==========
  Widget _buildDesktopNavigation() {
    return Row(
      children: [
        _buildDesktopNavItem('Home', 0, Icons.home_outlined),
        _buildDesktopNavItem('Menu', 1, Icons.restaurant_menu_outlined),
        _buildDesktopNavItem('Cart', 2, Icons.shopping_cart_outlined),
      ],
    );
  }

  Widget _buildDesktopNavItem(String label, int index, IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: TextButton(
        onPressed: () => setState(() => _currentIndex = index),
        style: TextButton.styleFrom(
          foregroundColor: _currentIndex == index 
              ? Colors.white 
              : Colors.white.withOpacity(0.7),
        ),
        child: Row(
          children: [
            Icon(icon, size: 18),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                fontWeight: _currentIndex == index 
                    ? FontWeight.w600 
                    : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCartIndicator() {
    return Padding(
      padding: const EdgeInsets.only(right: 16),
      child: Stack(
        children: [
          IconButton(
            icon: const Icon(Icons.shopping_cart_outlined),
            onPressed: () => setState(() => _currentIndex = 2),
          ),
          if (cartService.itemCount > 0)
            Positioned(
              right: 8,
              top: 8,
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: const BoxDecoration(
                  color: Colors.red,
                  shape: BoxShape.circle,
                ),
                child: Text(
                  '${cartService.itemCount}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildDesktopMenu() {
    return PopupMenuButton<String>(
      onSelected: (value) {
        _getMenuActions()[value]?.action();
      },
      itemBuilder: (context) => _buildMenuItems(),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(
          children: [
            CircleAvatar(
              radius: 16,
              backgroundColor: Colors.grey[800],
              child: _currentUser != null
                  ? Text(
                      _currentUser!.name[0].toUpperCase(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  : const Icon(Icons.person_outline, size: 18),
            ),
            const SizedBox(width: 8),
            const Icon(Icons.arrow_drop_down, color: Colors.white),
          ],
        ),
      ),
    );
  }

  // ========== BODY ==========
  Widget _buildBody() {
    switch (_currentIndex) {
      case 1:
        return MenuPage(cartService: cartService);
      case 2:
        return CartPage(
          cartService: cartService,
          currentUser: _currentUser,
        );
      default:
        return _buildHomeContent();
    }
  }

  Widget _buildHomeContent() {
    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: isDesktop ? 48 : 16,
          vertical: isDesktop ? 32 : 16,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // User Greeting
            if (_currentUser != null) _buildUserGreeting(),

            // Hero Section
            _buildHeroSection(),

            const SizedBox(height: 32),

            // Featured Items Grid/List
            _buildFeaturedSection(),

            const SizedBox(height: 32),

            // Today's Special
            _buildSpecialSection(),

            const SizedBox(height: 32),

            // Quick Actions
            _buildQuickActions(),

            const SizedBox(height: 64),
          ],
        ),
      ),
    );
  }

  // ========== HOME CONTENT SECTIONS ==========
  Widget _buildUserGreeting() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.only(bottom: 24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 24,
            backgroundColor: AppTheme.primaryColor,
            child: Text(
              _currentUser!.name[0].toUpperCase(),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Welcome back, ${_currentUser!.name}!',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Ready to order some delicious food?',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
          if (isDesktop)
            ElevatedButton(
              onPressed: () => setState(() => _currentIndex = 1),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryColor,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text('Order Now'),
            ),
        ],
      ),
    );
  }

  Widget _buildHeroSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppTheme.primaryColor.withOpacity(0.8),
            AppTheme.primaryColor,
            Colors.black.withOpacity(0.9),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryColor.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Delicious Food,\nDelivered Fast',
            style: TextStyle(
              fontSize: isDesktop ? 32 : 28,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              height: 1.2,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Fresh ingredients, authentic flavors, and quality you can taste in every bite.',
            style: TextStyle(
              fontSize: isDesktop ? 16 : 14,
              color: Colors.white.withOpacity(0.9),
              fontWeight: FontWeight.w400,
            ),
          ),
          const SizedBox(height: 24),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              ElevatedButton(
                onPressed: () => setState(() => _currentIndex = 1),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: AppTheme.primaryColor,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 14,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text(
                  'Browse Menu',
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
              OutlinedButton(
                onPressed: () {
                  if (_currentUser == null) {
                    _navigateToLogin();
                  } else {
                    setState(() => _currentIndex = 2);
                  }
                },
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: const BorderSide(color: Colors.white),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 14,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text('View Cart'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFeaturedSection() {
    final featuredItems = [
      {'title': '🍔 Beast Burger', 'desc': 'Double patty, extra cheese'},
      {'title': '🥗 Garden Salad', 'desc': 'Fresh veggies, light dressing'},
      {'title': '🍕 Deliti Special', 'desc': 'Loaded with toppings'},
      {'title': '🥤 Refreshers', 'desc': 'Cool drinks for hot days'},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Featured Items',
          style: TextStyle(
            fontSize: isDesktop ? 24 : 20,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 16),
        isDesktop || isTablet
            ? _buildFeaturedGrid(featuredItems)
            : _buildFeaturedList(featuredItems),
      ],
    );
  }

  Widget _buildFeaturedGrid(List<Map<String, String>> items) {
    final crossAxisCount = isDesktop ? 4 : 2;
    
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 1.2,
      ),
      itemCount: items.length,
      itemBuilder: (context, index) {
        return _buildFeaturedCard(items[index]);
      },
    );
  }

  Widget _buildFeaturedList(List<Map<String, String>> items) {
    return Column(
      children: items.map((item) {
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          child: _buildFeaturedCard(item),
        );
      }).toList(),
    );
  }

  Widget _buildFeaturedCard(Map<String, String> item) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              item['title']!,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              item['desc']!,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 12),
            TextButton(
              onPressed: () => setState(() => _currentIndex = 1),
              style: TextButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 0),
                foregroundColor: AppTheme.primaryColor,
              ),
              child: const Row(
                children: [
                  Text('Order Now'),
                  SizedBox(width: 4),
                  Icon(Icons.arrow_forward, size: 16),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSpecialSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppTheme.primaryColor.withOpacity(0.05),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppTheme.primaryColor.withOpacity(0.1),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppTheme.primaryColor,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  '🔥',
                  style: TextStyle(fontSize: 20),
                ),
              ),
              const SizedBox(width: 12),
              Text(
                'Today\'s Special',
                style: TextStyle(
                  fontSize: isDesktop ? 24 : 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            'BEAST BURGER',
            style: TextStyle(
              fontSize: isDesktop ? 32 : 24,
              fontWeight: FontWeight.w900,
              color: AppTheme.primaryColor,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Double beef patty, triple cheese, special sauce, and crispy bacon on a brioche bun.',
            style: TextStyle(
              fontSize: isDesktop ? 16 : 14,
              color: Colors.grey[700],
              height: 1.5,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              const Icon(Icons.star, color: Colors.amber, size: 20),
              const SizedBox(width: 4),
              Text(
                '4.8/5.0 (240+ reviews)',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colors.grey[700],
                ),
              ),
              const Spacer(),
              ElevatedButton(
                onPressed: () => setState(() => _currentIndex = 1),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.primaryColor,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 12,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text('Try It Now'),
              ),
            ],
          ),
        ],
      ),
    );
  }





  Widget _buildActionList(List<Map<String, dynamic>> actions) {
    return Column(
      children: actions.map((action) {
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          child: _buildActionCard(action),
        );
      }).toList(),
    );
  }

  Widget _buildActionCard(Map<String, dynamic> action) {
    return Card(
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              action['icon'] as IconData, // Cast to IconData
              color: AppTheme.primaryColor,
              size: 28,
            ),
            const SizedBox(height: 12),
            Text(
              action['label'] as String,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              action['desc'] as String,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }




Widget _buildQuickActions() {
  final actions = [
    {
      'icon': Icons.timer,
      'label': 'Fast Delivery',
      'desc': '30 min or free',
    },
    {
      'icon': Icons.verified,
      'label': 'Quality Guarantee',
      'desc': 'Fresh ingredients',
    },
    {
      'icon': Icons.phone,
      'label': 'Contact Us',
      'desc': '24/7 support',
    },
    {
      'icon': Icons.local_offer,
      'label': 'Daily Deals',
      'desc': 'Special offers',
    },
  ];

  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        'Why Choose Deliti',
        style: TextStyle(
          fontSize: isDesktop ? 24 : 20,
          fontWeight: FontWeight.w700,
        ),
      ),
      const SizedBox(height: 16),
      if (isMobile) _buildMobileActionRows(actions) else _buildActionGrid(actions),
    ],
  );
}

Widget _buildMobileActionRows(List<Map<String, dynamic>> actions) {
  return Column(
    children: [
      // First row: Fast Delivery & Quality Guarantee
      Row(
        children: [
          Expanded(
            child: _buildMobileActionCard(actions[0]),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildMobileActionCard(actions[1]),
          ),
        ],
      ),
      const SizedBox(height: 12),
      // Second row: Contact Us & Daily Deals
      Row(
        children: [
          Expanded(
            child: _buildMobileActionCard(actions[2]),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildMobileActionCard(actions[3]),
          ),
        ],
      ),
    ],
  );
}

Widget _buildMobileActionCard(Map<String, dynamic> action) {
  return Card(
    elevation: 1,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(12),
    ),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, // Left aligned
        children: [
          Row(
            children: [
              Icon(
                action['icon'] as IconData,
                color: AppTheme.primaryColor,
                size: 24,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      action['label'] as String,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      action['desc'] as String,
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[600],
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}

// Keep the existing _buildActionGrid method for desktop/tablet
Widget _buildActionGrid(List<Map<String, dynamic>> actions) {
  final crossAxisCount = isDesktop ? 4 : 2;
  
  return GridView.builder(
    shrinkWrap: true,
    physics: const NeverScrollableScrollPhysics(),
    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: crossAxisCount,
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      childAspectRatio: 1.5,
    ),
    itemCount: actions.length,
    itemBuilder: (context, index) {
      return _buildDesktopActionCard(actions[index]);
    },
  );
}

// Separate card for desktop/tablet (centered layout)
Widget _buildDesktopActionCard(Map<String, dynamic> action) {
  return Card(
    elevation: 1,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(12),
    ),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Icon(
            action['icon'] as IconData,
            color: AppTheme.primaryColor,
            size: 28,
          ),
          const SizedBox(height: 12),
          Text(
            action['label'] as String,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 4),
          Text(
            action['desc'] as String,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[600],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    ),
  );
}


  // ========== BOTTOM NAVIGATION ==========
  BottomNavigationBar _buildBottomNavBar() {
    return BottomNavigationBar(
      currentIndex: _currentIndex,
      onTap: (index) => setState(() => _currentIndex = index),
      selectedItemColor: AppTheme.primaryColor,
      unselectedItemColor: Colors.grey[600],
      selectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500),
      items: [
        const BottomNavigationBarItem(
          icon: Icon(Icons.home_outlined),
          activeIcon: Icon(Icons.home),
          label: 'Home',
        ),
        const BottomNavigationBarItem(
          icon: Icon(Icons.restaurant_menu_outlined),
          activeIcon: Icon(Icons.restaurant_menu),
          label: 'Menu',
        ),
        BottomNavigationBarItem(
          icon: Stack(
            children: [
              const Icon(Icons.shopping_cart_outlined),
              if (cartService.itemCount > 0)
                Positioned(
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: const BoxDecoration(
                      color: Colors.red,
                      shape: BoxShape.circle,
                    ),
                    constraints: const BoxConstraints(
                      minWidth: 12,
                      minHeight: 12,
                    ),
                  ),
                ),
            ],
          ),
          activeIcon: Stack(
            children: [
              const Icon(Icons.shopping_cart),
              if (cartService.itemCount > 0)
                Positioned(
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: const BoxDecoration(
                      color: Colors.red,
                      shape: BoxShape.circle,
                    ),
                    constraints: const BoxConstraints(
                      minWidth: 12,
                      minHeight: 12,
                    ),
                  ),
                ),
            ],
          ),
          label: 'Cart',
        ),
      ],
    );
  }
}