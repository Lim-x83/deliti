import 'package:flutter/material.dart';
import '../services/article_service.dart';
import '../models/article_model.dart';

class CreateArticlePage extends StatefulWidget {
  final Article? article;

  const CreateArticlePage({Key? key, this.article}) : super(key: key);

  @override
  State<CreateArticlePage> createState() => _CreateArticlePageState();
}

class _CreateArticlePageState extends State<CreateArticlePage> {
  final _titleController = TextEditingController();
  final _contentController = TextEditingController();
  final _authorController = TextEditingController();
  final _categoryController = TextEditingController();
  bool _isPublished = true;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.article != null) {
      _titleController.text = widget.article!.title;
      _contentController.text = widget.article!.content;
      _authorController.text = widget.article!.author;
      _categoryController.text = widget.article!.category;
      _isPublished = widget.article!.isPublished;
    }
  }

  Future<void> _saveArticle() async {
    if (_titleController.text.isEmpty || _contentController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill title and content')),
      );
      return;
    }

    setState(() => _isLoading = true);

    final article = Article(
      id: widget.article?.id ?? 0,
      title: _titleController.text,
      content: _contentController.text,
      author: _authorController.text.isNotEmpty ? _authorController.text : 'Admin',
      category: _categoryController.text.isNotEmpty ? _categoryController.text : 'General',
      isPublished: _isPublished,
      createdAt: widget.article?.createdAt ?? DateTime.now(),
      updatedAt: DateTime.now(),
    );

    final result = widget.article == null
        ? await ArticleService.createArticle(article)
        : await ArticleService.updateArticle(article);

    setState(() => _isLoading = false);

    if (result['success'] == true) {
      Navigator.pop(context, true);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result['message'] ?? 'Failed to save')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.article == null ? 'Create Article' : 'Edit Article'),
        backgroundColor: Colors.blue[800],
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _isLoading ? null : _saveArticle,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextFormField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Title *',
                border: OutlineInputBorder(),
                hintText: 'Enter article title',
              ),
              maxLines: 2,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _contentController,
              decoration: const InputDecoration(
                labelText: 'Content *',
                border: OutlineInputBorder(),
                hintText: 'Write your article here...',
                alignLabelWithHint: true,
              ),
              maxLines: 10,
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _authorController,
                    decoration: const InputDecoration(
                      labelText: 'Author',
                      border: OutlineInputBorder(),
                      hintText: 'Admin',
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: TextFormField(
                    controller: _categoryController,
                    decoration: const InputDecoration(
                      labelText: 'Category',
                      border: OutlineInputBorder(),
                      hintText: 'General',
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Checkbox(
                  value: _isPublished,
                  onChanged: (value) => setState(() => _isPublished = value ?? true),
                ),
                const Text('Publish immediately'),
                const Spacer(),
                if (_isLoading) const CircularProgressIndicator(),
              ],
            ),
          ],
        ),
      ),
    );
  }
}