// lib/pages/purchasing_page.dart
import 'package:flutter/material.dart';
import '../models/purchasing_model.dart';
import '../services/purchasing_service.dart';

class PurchasingPage extends StatefulWidget {
  const PurchasingPage({Key? key}) : super(key: key);

  @override
  State<PurchasingPage> createState() => _PurchasingPageState();
}

class _PurchasingPageState extends State<PurchasingPage> {
  List<PurchasingItem> _purchasingList = []; // Changed from PurchasingModel to PurchasingItem
  double _totalHarga = 0;
  bool _isLoading = true;
  String _error = '';

  @override
  void initState() {
    super.initState();
    _loadPurchasing();
  }

  Future<void> _loadPurchasing() async {
    try {
      setState(() {
        _isLoading = true;
        _error = '';
      });
      
      print('🔄 [_PurchasingPageState] Loading purchasing...');
      final items = await PurchasingService.getPurchasing(); // Now returns List<PurchasingItem>
      
      print('📦 [_PurchasingPageState] Items count: ${items.length}');
      
      // Calculate total harga
      double total = 0;
      for (var item in items) {
        total += item.harga * item.jumlahBarang;
      }
      
      setState(() {
        _purchasingList = items;
        _totalHarga = total;
        _isLoading = false;
      });
      
    } catch (e) {
      setState(() {
        _error = "Error: $e";
        _isLoading = false;
      });
      print('❌ [_PurchasingPageState] Exception: $e');
    }
  }

  String _formatCurrency(double amount) {
    if (amount == 0) return "Rp 0";
    return 'Rp ${amount.toStringAsFixed(0).replaceAllMapped(
      RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
      (Match m) => '${m[1]}.',
    )}';
  }

  String _formatDate(DateTime? date) {
    if (date == null) return "N/A";
    return "${date.day}/${date.month}/${date.year}";
  }

  void _showAddPurchasingDialog() {
    showDialog(
      context: context,
      builder: (context) => AddPurchasingDialog(
        onAdded: () {
          _loadPurchasing();
        },
      ),
    );
  }

  void _showDeleteDialog(int id, String namaBarang) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Hapus Data"),
        content: Text("Yakin hapus '$namaBarang'?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Batal"),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              final response = await PurchasingService.deletePurchase(id);
              if (response['success'] == true) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("Data berhasil dihapus"),
                    backgroundColor: Colors.green,
                  ),
                );
                _loadPurchasing();
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text("Gagal: ${response['message']}"),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            child: const Text("Hapus", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Purchasing Management'),
        backgroundColor: Colors.blue[800],
        foregroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _buildBody(),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddPurchasingDialog,
        backgroundColor: Colors.blue[800],
        foregroundColor: Colors.white,
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 20),
            Text("Loading purchasing data..."),
          ],
        ),
      );
    }

    if (_error.isNotEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 60, color: Colors.red),
            const SizedBox(height: 20),
            Text("Error: $_error", textAlign: TextAlign.center),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _loadPurchasing,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue[800],
              ),
              child: const Text("Try Again", style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        // Header with stats
        Card(
          margin: const EdgeInsets.all(16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                const Text(
                  'Purchasing Summary',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: [
                        const Icon(Icons.list, color: Colors.blue, size: 32),
                        const SizedBox(height: 8),
                        Text(
                          '${_purchasingList.length}',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Text('Items'),
                      ],
                    ),
                    Column(
                      children: [
                        const Icon(Icons.attach_money, color: Colors.green, size: 32),
                        const SizedBox(height: 8),
                        Text(
                          _formatCurrency(_totalHarga),
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Text('Total'),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),

        // List of items
        Expanded(
          child: _purchasingList.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.shopping_cart, size: 60, color: Colors.grey),
                      SizedBox(height: 16),
                      Text(
                        'No purchasing data',
                        style: TextStyle(fontSize: 18, color: Colors.grey),
                      ),
                      Text(
                        'Add your first purchase',
                        style: TextStyle(color: Colors.grey),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _purchasingList.length,
                  itemBuilder: (context, index) {
                    final item = _purchasingList[index];
                    return _buildPurchasingCard(item);
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildPurchasingCard(PurchasingItem item) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    item.namaBarang,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () => _showDeleteDialog(item.id, item.namaBarang),
                ),
              ],
            ),

            const SizedBox(height: 8),

            // Kode and Vendor
            Row(
              children: [
                const Icon(Icons.tag, size: 16, color: Colors.grey),
                const SizedBox(width: 6),
                Text(
                  'Kode: ${item.kode}',
                  style: TextStyle(color: Colors.grey[600]),
                ),
                const Spacer(),
                const Icon(Icons.store, size: 16, color: Colors.grey),
                const SizedBox(width: 6),
                Text(
                  item.vendor,
                  style: TextStyle(color: Colors.grey[600]),
                ),
              ],
            ),

            const SizedBox(height: 8),

            // Quantity and Unit
            Row(
              children: [
                const Icon(Icons.scale, size: 16, color: Colors.grey),
                const SizedBox(width: 6),
                Text(
                  '${item.jumlahBarang} ${item.satuanKuantitas}',
                  style: TextStyle(color: Colors.grey[600]),
                ),
                if (item.lokasiBarang != null && item.lokasiBarang!.isNotEmpty) ...[
                  const Spacer(),
                  const Icon(Icons.location_on, size: 16, color: Colors.grey),
                  const SizedBox(width: 6),
                  Text(
                    item.lokasiBarang!,
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                ],
              ],
            ),

            const SizedBox(height: 8),

            // Price and Date
            Row(
              children: [
                Icon(Icons.attach_money, size: 16, color: Colors.green[700]),
                const SizedBox(width: 6),
                Text(
                  _formatCurrency(item.harga),
                  style: TextStyle(
                    color: Colors.green[700],
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  '× ${item.jumlahBarang} = ${_formatCurrency(item.totalHarga)}',
                  style: TextStyle(
                    color: Colors.green[700],
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                const Icon(Icons.calendar_today, size: 16, color: Colors.grey),
                const SizedBox(width: 6),
                Text(
                  _formatDate(item.tanggalTransaksi),
                  style: TextStyle(color: Colors.grey[600]),
                ),
              ],
            ),

            if (item.expiredDate != null) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  Icon(
                    Icons.warning,
                    size: 16,
                    color: item.expiredDate!.isBefore(DateTime.now().add(const Duration(days: 30)))
                        ? Colors.orange
                        : Colors.grey,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    'Expires: ${_formatDate(item.expiredDate)}',
                    style: TextStyle(
                      color: item.expiredDate!.isBefore(DateTime.now().add(const Duration(days: 30)))
                          ? Colors.orange
                          : Colors.grey[600],
                      fontWeight: item.expiredDate!.isBefore(DateTime.now().add(const Duration(days: 30)))
                          ? FontWeight.bold
                          : FontWeight.normal,
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ========== ADD PURCHASING DIALOG ==========
class AddPurchasingDialog extends StatefulWidget {
  final VoidCallback onAdded;
  
  const AddPurchasingDialog({Key? key, required this.onAdded}) : super(key: key);

  @override
  State<AddPurchasingDialog> createState() => _AddPurchasingDialogState();
}

class _AddPurchasingDialogState extends State<AddPurchasingDialog> {
  final _formKey = GlobalKey<FormState>();
  final _namaController = TextEditingController();
  final _jumlahController = TextEditingController();
  final _satuanController = TextEditingController();
  final _lokasiController = TextEditingController();
  final _hargaController = TextEditingController();
  final _vendorController = TextEditingController();
  DateTime? _expiredDate;
  bool _isSubmitting = false;

  Future<void> _selectExpiredDate(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(const Duration(days: 365)),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365 * 5)),
    );
    
    if (picked != null) {
      setState(() => _expiredDate = picked);
    }
  }

  Future<void> _submitPurchasing() async {
    if (!_formKey.currentState!.validate()) return;
    if (_expiredDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Expired date is required"),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    final response = await PurchasingService.addPurchase(
      namaBarang: _namaController.text,
      jumlahBarang: int.parse(_jumlahController.text),
      satuanKuantitas: _satuanController.text,
      lokasiBarang: _lokasiController.text,
      expiredDate: _expiredDate!,
      harga: double.parse(_hargaController.text),
      vendor: _vendorController.text,
    );

    setState(() => _isSubmitting = false);

    if (response['success'] == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(response['message'] ?? "Purchase added successfully"),
          backgroundColor: Colors.green,
        ),
      );
      Navigator.pop(context);
      widget.onAdded();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Failed: ${response['message']}"),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  void dispose() {
    _namaController.dispose();
    _jumlahController.dispose();
    _satuanController.dispose();
    _lokasiController.dispose();
    _hargaController.dispose();
    _vendorController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text("Add New Purchase"),
      content: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _namaController,
                decoration: const InputDecoration(
                  labelText: "Product Name *",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.shopping_basket),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Product name is required";
                  }
                  return null;
                },
              ),
              
              const SizedBox(height: 12),
              
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _jumlahController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: "Quantity *",
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.numbers),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return "Quantity is required";
                        }
                        if (int.tryParse(value) == null) {
                          return "Enter a valid number";
                        }
                        return null;
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _satuanController,
                      decoration: const InputDecoration(
                        labelText: "Unit *",
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.scale),
                        hintText: "kg, pcs, liter",
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return "Unit is required";
                        }
                        return null;
                      },
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 12),
              
              TextFormField(
                controller: _lokasiController,
                decoration: const InputDecoration(
                  labelText: "Location (optional)",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.location_on),
                  hintText: "Storage Room, Freezer, etc.",
                ),
              ),
              
              const SizedBox(height: 12),
              
              InkWell(
                onTap: () => _selectExpiredDate(context),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey[400]!),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.calendar_today, color: Colors.blue),
                      const SizedBox(width: 12),
                      Text(
                        _expiredDate == null
                            ? "Select Expiry Date *"
                            : "Expires: ${_expiredDate!.day}/${_expiredDate!.month}/${_expiredDate!.year}",
                        style: TextStyle(
                          color: _expiredDate == null ? Colors.grey : Colors.black,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 12),
              
              TextFormField(
                controller: _hargaController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "Price per Unit *",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.attach_money),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Price is required";
                  }
                  if (double.tryParse(value) == null) {
                    return "Enter a valid price";
                  }
                  return null;
                },
              ),
              
              const SizedBox(height: 12),
              
              TextFormField(
                controller: _vendorController,
                decoration: const InputDecoration(
                  labelText: "Vendor *",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.store),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Vendor is required";
                  }
                  return null;
                },
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: _isSubmitting ? null : () => Navigator.pop(context),
          child: const Text("Cancel"),
        ),
        ElevatedButton(
          onPressed: _isSubmitting ? null : _submitPurchasing,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue[800],
          ),
          child: _isSubmitting
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
              : const Text("Save", style: TextStyle(color: Colors.white)),
        ),
      ],
    );
  }
}