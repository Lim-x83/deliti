import 'package:apk_deliti/pages/ar_page.dart';
import 'package:apk_deliti/pages/profile_page.dart';
import 'package:apk_deliti/pages/profit_page.dart';
import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../themes/app_theme.dart';
import 'ap_page.dart';
import 'inventory_page.dart';
import 'manage_users_page.dart';
import 'purchasing_page.dart';
import 'vendor_page.dart';
import 'order_management_page.dart';

// ========== RESPONSIVE DASHBOARD ==========

class AdminDashboardPage extends StatelessWidget {
  final User user;
  
  const AdminDashboardPage({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    // Move responsive helpers inside build method
    final isDesktop = MediaQuery.of(context).size.width >= 1024;
    final isTablet = MediaQuery.of(context).size.width >= 600;
    final isMobile = !isTablet;
    
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: const Text('Admin Dashboard'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('No new notifications')),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ProfilePage(currentUser: user),
                ),
              );
            },
          ),
        ],
      ),
      body: _buildDashboardBody(context, isDesktop, isTablet, isMobile),
    );
  }

  Widget _buildDashboardBody(BuildContext context, bool isDesktop, bool isTablet, bool isMobile) {
    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: isDesktop ? 32 : 16,
          vertical: 20,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with greeting
            _buildHeader(context, user, isDesktop),
            
            const SizedBox(height: 24),
            
            // Quick stats (desktop only) or simple welcome (mobile)
            if (isDesktop) _buildDesktopStats() else _buildMobileHeader(),
            
            const SizedBox(height: 32),
            
            // Quick actions
            _buildQuickActionsSection(context, isDesktop),
            
            const SizedBox(height: 32),
            
            // Main dashboard sections
            _buildDashboardSections(context, isDesktop, user),
            
            const SizedBox(height: 32),
            
            // Recent activities
            _buildRecentActivities(context, isDesktop),
            
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context, User user, bool isDesktop) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Welcome back, ${user.name}!',
              style: TextStyle(
                fontSize: isDesktop ? 28 : 22,
                fontWeight: FontWeight.w800,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Here\'s what\'s happening with your business',
              style: TextStyle(
                fontSize: isDesktop ? 16 : 14,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
        
        // Date and time widget
        if (isDesktop)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                const Icon(Icons.calendar_today, size: 18, color: Colors.grey),
                const SizedBox(width: 8),
                Text(
                  DateTime.now().toString().split(' ')[0],
                  style: const TextStyle(
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildDesktopStats() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.black, Colors.grey[900]!],
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStatItem('Today\'s Revenue', 'Rp 1.8M', Icons.attach_money, Colors.green),
          _buildStatItem('Active Orders', '24', Icons.shopping_cart, Colors.blue),
          _buildStatItem('New Customers', '8', Icons.people, Colors.orange),
          _buildStatItem('Pending Tasks', '6', Icons.task, Colors.red),
        ],
      ),
    );
  }

  Widget _buildStatItem(String title, String value, IconData icon, Color color) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: color, size: 24),
        ),
        const SizedBox(height: 12),
        Text(
          value,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          title,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[400],
          ),
        ),
      ],
    );
  }

  Widget _buildMobileHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.purple.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.admin_panel_settings,
              color: Colors.purple,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Administrator Mode',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey[700],
                  ),
                ),
                Text(
                  'Full system access',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[500],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionsSection(BuildContext context, bool isDesktop) {
    final quickActions = _getQuickActions(context);
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Actions',
          style: TextStyle(
            fontSize: isDesktop ? 20 : 18,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 16),
        
        isDesktop 
            ? _buildDesktopQuickActions(quickActions)
            : _buildMobileQuickActions(quickActions),
      ],
    );
  }

  Widget _buildDesktopQuickActions(List<QuickAction> actions) {
    return Row(
      children: actions.map((action) {
        return Expanded(
          child: Container(
            margin: const EdgeInsets.only(right: 12),
            child: _buildQuickActionCard(action),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildMobileQuickActions(List<QuickAction> actions) {
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: actions.map((action) {
        return _buildQuickActionChip(action);
      }).toList(),
    );
  }

  Widget _buildQuickActionCard(QuickAction action) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: action.onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: action.color.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(action.icon, color: action.color, size: 24),
              ),
              const SizedBox(height: 12),
              Text(
                action.label,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQuickActionChip(QuickAction action) {
    return ActionChip(
      avatar: Icon(action.icon, size: 18, color: action.color),
      label: Text(action.label),
      backgroundColor: action.color.withOpacity(0.1),
      onPressed: action.onTap,
      labelStyle: TextStyle(
        color: Colors.grey[800],
        fontWeight: FontWeight.w500,
      ),
    );
  }

  Widget _buildDashboardSections(BuildContext context, bool isDesktop, User user) {
    final sections = _getDashboardSections(context, user);
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Dashboard',
          style: TextStyle(
            fontSize: isDesktop ? 20 : 18,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 16),
        
        isDesktop 
            ? _buildDesktopSections(sections)
            : _buildMobileSections(sections),
      ],
    );
  }

  Widget _buildDesktopSections(List<DashboardSection> sections) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 1.2,
      ),
      itemCount: sections.length,
      itemBuilder: (context, index) {
        return _buildDashboardCard(sections[index]);
      },
    );
  }

  Widget _buildMobileSections(List<DashboardSection> sections) {
    return Column(
      children: sections.map((section) {
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          child: _buildDashboardCard(section),
        );
      }).toList(),
    );
  }

  Widget _buildDashboardCard(DashboardSection section) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: section.onTap,
        child: Container(
          decoration: BoxDecoration(
            gradient: section.gradient,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        section.icon,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                    
                    // Stats badges
                    Row(
                      children: section.stats.entries.map((entry) {
                        return Container(
                          margin: const EdgeInsets.only(left: 6),
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            entry.value,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
                
                const SizedBox(height: 20),
                
                Text(
                  section.title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
                
                const SizedBox(height: 8),
                
                Text(
                  section.description,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.white.withOpacity(0.9),
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                
                const SizedBox(height: 16),
                
                Align(
                  alignment: Alignment.centerRight,
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.arrow_forward,
                      color: Colors.white,
                      size: 16,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRecentActivities(BuildContext context, bool isDesktop) {
    final activities = _getRecentActivities();
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Recent Activity',
              style: TextStyle(
                fontSize: isDesktop ? 20 : 18,
                fontWeight: FontWeight.w700,
              ),
            ),
            TextButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Viewing all activities')),
                );
              },
              child: const Text('View All'),
            ),
          ],
        ),
        
        const SizedBox(height: 16),
        
        Card(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: activities.map((activity) {
                return Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        color: Colors.grey[200]!,
                        width: 1,
                      ),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: activity.color.withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          activity.icon,
                          size: 20,
                          color: activity.color,
                        ),
                      ),
                      
                      const SizedBox(width: 16),
                      
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              activity.title,
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              activity.subtitle,
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      Text(
                        activity.time,
                        style: TextStyle(
                          fontSize: 11,
                          color: Colors.grey[500],
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
        ),
      ],
    );
  }

  // ========== DATA METHODS ==========
  List<DashboardSection> _getDashboardSections(BuildContext context, User user) {
    return [
      DashboardSection(
        title: 'Order Management',
        icon: Icons.shopping_cart,
        color: Colors.green,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.green, Color(0xFF4CAF50)],
        ),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => OrderManagementPage()),
        ),
        description: 'View and manage customer orders',
        stats: const {'pending': '12', 'completed': '89'},
      ),
      DashboardSection(
        title: 'Vendor Management',
        icon: Icons.store,
        color: Colors.purple,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.purple, Color(0xFF9C27B0)],
        ),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => VendorPage(user: user)),
        ),
        description: 'Manage suppliers and partnerships',
        stats: const {'active': '8', 'pending': '3'},
      ),
      DashboardSection(
        title: 'User Management',
        icon: Icons.people,
        color: Colors.orange,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.orange, Color(0xFFFF9800)],
        ),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => ManageUsersPage(currentUser: user)),
        ),
        description: 'Manage customer accounts and permissions',
        stats: const {'users': '156', 'active': '89'},
      ),
      DashboardSection(
        title: 'Inventory',
        icon: Icons.inventory_2,
        color: Colors.blue,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.blue, Color(0xFF2196F3)],
        ),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => InventoryPage()),
        ),
        description: 'Track stock levels and expiry dates',
        stats: const {'low': '5', 'total': '245'},
      ),
      DashboardSection(
        title: 'Purchasing',
        icon: Icons.shopping_basket,
        color: Colors.teal,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.teal, Color(0xFF009688)],
        ),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => PurchasingPage()),
        ),
        description: 'Manage purchase orders and deliveries',
        stats: const {'pending': '7', 'completed': '42'},
      ),
      DashboardSection(
        title: 'Finance',
        icon: Icons.attach_money,
        color: Colors.red,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.red, Color(0xFFF44336)],
        ),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => ProfitPage()),
        ),
        description: 'Revenue, profit, and financial reports',
        stats: const {'revenue': 'Rp 4.2M', 'profit': 'Rp 1.8M'},
      ),
      DashboardSection(
        title: 'Accounts Receivable',
        icon: Icons.receipt_long,
        color: Colors.indigo,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.indigo, Color(0xFF3F51B5)],
        ),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => ArPage()),
        ),
        description: 'Track customer payments and invoices',
        stats: const {'pending': 'Rp 850K', 'collected': 'Rp 2.1M'},
      ),
      DashboardSection(
        title: 'Accounts Payable',
        icon: Icons.payment,
        color: Colors.cyan,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.cyan, Color(0xFF00BCD4)],
        ),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => ApPage()),
        ),
        description: 'Manage vendor payments and bills',
        stats: const {'due': 'Rp 1.2M', 'paid': 'Rp 3.4M'},
      ),
    ];
  }

  List<QuickAction> _getQuickActions(BuildContext context) {
    return [
      QuickAction(
        label: 'New Order',
        icon: Icons.add_shopping_cart,
        color: Colors.green,
        onTap: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('New order feature coming soon!')),
          );
        },
      ),
      QuickAction(
        label: 'Add Product',
        icon: Icons.add_circle,
        color: Colors.blue,
        onTap: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Add product feature coming soon!')),
          );
        },
      ),
      QuickAction(
        label: 'Generate Report',
        icon: Icons.bar_chart,
        color: Colors.purple,
        onTap: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Report generation coming soon!')),
          );
        },
      ),
      QuickAction(
        label: 'Send Alert',
        icon: Icons.notifications_active,
        color: Colors.orange,
        onTap: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Alert system coming soon!')),
          );
        },
      ),
    ];
  }

  List<Activity> _getRecentActivities() {
    return [
      Activity(
        title: 'New order #1001',
        subtitle: 'Customer: John Doe • Amount: Rp 125,000',
        time: '2 min ago',
        icon: Icons.shopping_cart,
        color: Colors.green,
      ),
      Activity(
        title: 'Low stock alert',
        subtitle: 'Product: Beef Patty • Stock: 12 units',
        time: '15 min ago',
        icon: Icons.warning,
        color: Colors.orange,
      ),
      Activity(
        title: 'Payment received',
        subtitle: 'Vendor: Fresh Produce Co. • Amount: Rp 450,000',
        time: '1 hour ago',
        icon: Icons.payment,
        color: Colors.blue,
      ),
      Activity(
        title: 'New user registered',
        subtitle: 'User: jane.smith@email.com',
        time: '2 hours ago',
        icon: Icons.person_add,
        color: Colors.purple,
      ),
    ];
  }
}

// ========== DATA MODELS ==========
class DashboardSection {
  final String title;
  final IconData icon;
  final Color color;
  final Gradient gradient;
  final VoidCallback onTap;
  final String description;
  final Map<String, String> stats;
  
  const DashboardSection({
    required this.title,
    required this.icon,
    required this.color,
    required this.gradient,
    required this.onTap,
    required this.description,
    required this.stats,
  });
}

class QuickAction {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  
  const QuickAction({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });
}

class Activity {
  final String title;
  final String subtitle;
  final String time;
  final IconData icon;
  final Color color;
  
  const Activity({
    required this.title,
    required this.subtitle,
    required this.time,
    required this.icon,
    required this.color,
  });
}