import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/api_service.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ManageUsersPage extends StatefulWidget {
  final User currentUser;
  
  const ManageUsersPage({Key? key, required this.currentUser}) : super(key: key);

  @override
  State<ManageUsersPage> createState() => _ManageUsersPageState();
}

class _ManageUsersPageState extends State<ManageUsersPage> {
  List<User> _users = [];
  bool _isLoading = true;
  String _error = '';

  @override
  void initState() {
    super.initState();
    _loadUsers();
  }

  Future<void> _loadUsers() async {
    try {
      setState(() => _isLoading = true);
      // We'll create this API method next
      final users = await _fetchUsers();
      setState(() {
        _users = users;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to load users: $e';
        _isLoading = false;
      });
    }
  }

  Future<List<User>> _fetchUsers() async {
    try {
      print('🔄 [ManageUsers] Starting fetch...');
      
      // DIRECT API CALL FOR DEBUGGING
      final url = Uri.parse('${ApiService.baseUrl}/users/get_users.php');
      print('🌐 [ManageUsers] Calling URL: $url');
      
      final response = await http.get(url).timeout(const Duration(seconds: 10));
      
      print('📦 [ManageUsers] HTTP Status: ${response.statusCode}');
      print('📦 [ManageUsers] Response body first 500 chars: ${response.body.length > 500 ? response.body.substring(0, 500) : response.body}');
      
      if (response.statusCode == 200) {
        try {
          final data = jsonDecode(response.body);
          print('✅ [ManageUsers] JSON decoded successfully');
          print('✅ [ManageUsers] success field: ${data['success']}');
          print('✅ [ManageUsers] data type: ${data['data']?.runtimeType}');
          print('✅ [ManageUsers] data length: ${data['data'] is List ? (data['data'] as List).length : 'Not a list'}');
          
          if (data['success'] == true && data['data'] is List) {
            List<dynamic> usersData = data['data'];
            print('🎉 [ManageUsers] Found ${usersData.length} users in response');
            
            List<User> users = [];
            for (var userJson in usersData) {
              print('👤 [ManageUsers] Processing user: $userJson');
              users.add(User.fromJson({
                'id': userJson['id'],
                'name': userJson['name'] ?? 'Unknown',
                'email': userJson['email'] ?? '',
                'phone': userJson['phone'] ?? '',
                'role': userJson['role'] ?? 'user',
              }));
            }
            return users;
          } else {
            print('❌ [ManageUsers] API returned false or no data');
            print('❌ [ManageUsers] Message: ${data['message']}');
          }
        } catch (e) {
          print('❌ [ManageUsers] JSON decode error: $e');
        }
      }
      
      // If we reach here, something went wrong
      print('⚠️ [ManageUsers] Falling back to current user only');
      return [widget.currentUser];
      
    } catch (e) {
      print('❌ [ManageUsers] Exception: $e');
      return [widget.currentUser];
    }
  }



  Color _getRoleColor(String role) {
    switch (role) {
      case 'admin': return Colors.red;
      case 'manager': return Colors.orange;
      case 'staff': return Colors.purple;
      default: return Colors.blue;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Manage Users'),
        backgroundColor: Colors.purple,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error.isNotEmpty
              ? Center(child: Text(_error))
              : Column(
                  children: [
                    // Header
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            '👥 User Management',
                            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            '${_users.length} users in system',
                            style: const TextStyle(color: Colors.grey),
                          ),
                        ],
                      ),
                    ),

                    // User Table
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey[300]!),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: SingleChildScrollView(
                              scrollDirection: Axis.vertical,
                              child: DataTable(
                                columnSpacing: 20,
                                horizontalMargin: 12,
                                columns: const [
                                  DataColumn(label: SizedBox(width: 60, child: Text('ID'))),
                                  DataColumn(label: SizedBox(width: 150, child: Text('Name'))),
                                  DataColumn(label: SizedBox(width: 200, child: Text('Email'))),
                                  DataColumn(label: SizedBox(width: 120, child: Text('Phone'))),
                                  DataColumn(label: SizedBox(width: 100, child: Text('Role'))),
                                  DataColumn(label: SizedBox(width: 100, child: Text('Actions'))),
                                ],
                                rows: _users.map((user) {
                                  return DataRow(
                                    cells: [
                                      DataCell(Text('${user.id}')),
                                      DataCell(Text(user.name)),
                                      DataCell(Text(user.email)),
                                      DataCell(Text(user.phone)),
                                      DataCell(
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                          decoration: BoxDecoration(
                                            color: _getRoleColor(user.role).withOpacity(0.1),
                                            borderRadius: BorderRadius.circular(4),
                                          ),
                                          child: Text(
                                            user.role.toUpperCase(),
                                            style: TextStyle(
                                              color: _getRoleColor(user.role),
                                              fontWeight: FontWeight.bold,
                                              fontSize: 12,
                                            ),
                                          ),
                                        ),
                                      ),
                                      DataCell(
                                        Row(
                                          children: [
                                            IconButton(
                                              icon: const Icon(Icons.edit, size: 18, color: Colors.blue),
                                              onPressed: () {
                                                // Edit user
                                              },
                                            ),
                                            IconButton(
                                              icon: const Icon(Icons.delete, size: 18, color: Colors.red),
                                              onPressed: () {
                                                // Delete user
                                              },
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  );
                                }).toList(),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),

                    // Footer
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        children: [
                          // Stats
                          Card(
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                children: [
                                  _buildStat('Total Users', '${_users.length}', Colors.blue),
                                  _buildStat('Admins', '${_users.where((u) => u.role == 'admin').length}', Colors.red),
                                  _buildStat('Regular', '${_users.where((u) => u.role == 'user').length}', Colors.green),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
    );
  }

  Widget _buildStat(String title, String value, Color color) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            value,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ),
        const SizedBox(height: 4),
        Text(title, style: const TextStyle(fontSize: 12, color: Colors.grey)),
      ],
    );
  }
}