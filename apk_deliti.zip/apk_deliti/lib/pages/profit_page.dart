import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/purchasing_service.dart';
import '../models/order_model.dart';
import '../models/purchasing_model.dart';

class TopIncomeSource {
  final String name;
  double amount;
  int count;
  
  TopIncomeSource({
    required this.name,
    required this.amount,
    required this.count,
  });
}

class InsightItem {
  final String label;
  final String value;
  final String? subtitle;
  
  InsightItem({
    required this.label,
    required this.value,
    this.subtitle,
  });
}

class ProfitPage extends StatefulWidget {
  const ProfitPage({Key? key}) : super(key: key);

  @override
  State<ProfitPage> createState() => _ProfitPageState();
}

class _ProfitPageState extends State<ProfitPage> {
  String _selectedPeriod = 'month';
  DateTime? _startDate;
  DateTime? _endDate;
  double _totalIncome = 0;
  double _totalExpense = 0;
  double _netProfit = 0;
  double _profitMargin = 0;
  bool _isLoading = false;
  String _error = '';
  List<Map<String, dynamic>> _recentTransactions = [];
  List<Map<String, dynamic>> _topExpenses = [];
  List<TopIncomeSource> _topIncomeSources = [];
  Map<String, double> _expenseByCategory = {};
  
  bool get isDesktop => MediaQuery.of(context).size.width >= 1024;
  bool get isTablet => MediaQuery.of(context).size.width >= 600;

  final List<Map<String, String>> _periods = [
    {'value': 'today', 'label': 'Today'},
    {'value': 'week', 'label': 'This Week'},
    {'value': 'month', 'label': 'This Month'},
    {'value': 'year', 'label': 'This Year'},
    {'value': 'all', 'label': 'All Time'},
  ];

  @override
  void initState() {
    super.initState();
    _setDateRange('month');
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadProfitData();
    });
  }

  void _setDateRange(String period) {
    final now = DateTime.now();
    setState(() {
      _selectedPeriod = period;
      switch (period) {
        case 'today':
          _startDate = DateTime(now.year, now.month, now.day);
          _endDate = DateTime(now.year, now.month, now.day, 23, 59, 59);
          break;
        case 'week':
          _startDate = now.subtract(const Duration(days: 7));
          _endDate = now;
          break;
        case 'month':
          _startDate = DateTime(now.year, now.month, 1);
          _endDate = now;
          break;
        case 'year':
          _startDate = DateTime(now.year, 1, 1);
          _endDate = now;
          break;
        case 'all':
        default:
          _startDate = null;
          _endDate = null;
          break;
      }
    });
  }

  Future<void> _loadProfitData() async {
    try {
      setState(() {
        _isLoading = true;
        _error = '';
      });
      
      _totalIncome = 0;
      _totalExpense = 0;
      _netProfit = 0;
      _profitMargin = 0;
      _recentTransactions.clear();
      _topExpenses.clear();
      _topIncomeSources.clear();
      _expenseByCategory.clear();

      // 1. Load Income from COMPLETED orders
      final List<Order> ordersResponse = await ApiService.getOrders();
      final List<Order> completedOrders = ordersResponse
          .where((order) => order.status == 'completed' && _isDateInRange(order.createdAt))
          .toList();
      
      for (var order in completedOrders) {
        _totalIncome += order.totalPrice;
        
        _recentTransactions.add({
          'type': 'income',
          'amount': order.totalPrice,
          'description': 'Order #${order.id}',
          'date': order.createdAt,
          'category': 'Food Sales',
        });

        // Process order items - FIXED VERSION
        for (var item in order.items) {
          try {
            // Convert item to map
            final Map<String, dynamic> itemMap = _convertToMap(item);
            
            final itemName = itemMap['name']?.toString() ?? 'Unknown Item';
            
            // Parse price
            double price = 0.0;
            final priceValue = itemMap['price'];
            if (priceValue != null) {
              if (priceValue is double) {
                price = priceValue;
              } else if (priceValue is int) {
                price = priceValue.toDouble();
              } else if (priceValue is String) {
                price = double.tryParse(priceValue) ?? 0.0;
              } else {
                price = double.tryParse(priceValue.toString()) ?? 0.0;
              }
            }
            
            // Parse quantity
            int quantity = 1;
            final quantityValue = itemMap['quantity'];
            if (quantityValue != null) {
              if (quantityValue is int) {
                quantity = quantityValue;
              } else if (quantityValue is String) {
                quantity = int.tryParse(quantityValue) ?? 1;
              } else if (quantityValue is double) {
                quantity = quantityValue.toInt();
              } else {
                quantity = int.tryParse(quantityValue.toString()) ?? 1;
              }
            }
            
            final double itemTotal = price * quantity;

            final existingIndex = _topIncomeSources.indexWhere((source) => source.name == itemName);

            if (existingIndex == -1) {
              _topIncomeSources.add(TopIncomeSource(
                name: itemName,
                amount: itemTotal,
                count: 1,
              ));
            } else {
              _topIncomeSources[existingIndex].amount += itemTotal;
              _topIncomeSources[existingIndex].count += 1;
            }
          } catch (e) {
            print('⚠️ Error processing item: $e');
          }
        }
      }

      // 2. Load Expenses from Purchasing
      final List<PurchasingItem> purchasingResponse = await PurchasingService.getPurchasing();
      final List<PurchasingItem> filteredPurchases = purchasingResponse
          .where((purchase) => _isDateInRange(purchase.tanggalTransaksi))
          .toList();
      
      for (var purchase in filteredPurchases) {
        final totalExpense = purchase.harga * purchase.jumlahBarang;
        _totalExpense += totalExpense;
        
        final category = 'Supplies';
        
        _recentTransactions.add({
          'type': 'expense',
          'amount': totalExpense,
          'description': purchase.namaBarang,
          'date': purchase.tanggalTransaksi,
          'category': category,
          'vendor': purchase.vendor,
        });

        _topExpenses.add({
          'name': purchase.namaBarang,
          'amount': totalExpense,
          'vendor': purchase.vendor,
          'date': purchase.tanggalTransaksi,
        });

        _expenseByCategory[category] = (_expenseByCategory[category] ?? 0) + totalExpense;
      }

      // 3. Sort and limit top lists
      _topIncomeSources.sort((a, b) => b.amount.compareTo(a.amount));
      if (_topIncomeSources.length > 5) {
        _topIncomeSources = _topIncomeSources.sublist(0, 5);
      }
      
      _topExpenses.sort((a, b) => (b['amount'] as double).compareTo(a['amount'] as double));
      if (_topExpenses.length > 5) {
        _topExpenses = _topExpenses.sublist(0, 5);
      }

      // 4. Calculate Profit
      _netProfit = _totalIncome - _totalExpense;
      _profitMargin = _totalIncome > 0 ? (_netProfit / _totalIncome) * 100 : 0;

      setState(() {
        _isLoading = false;
      });

    } catch (e) {
      setState(() {
        _error = "Error loading data: $e";
        _isLoading = false;
      });
    }
  }

  // Helper method to convert dynamic to Map
  Map<String, dynamic> _convertToMap(dynamic item) {
    if (item is Map<String, dynamic>) {
      return item;
    } else if (item is Map) {
      return Map<String, dynamic>.from(item);
    } else {
      return {};
    }
  }

  bool _isDateInRange(DateTime date) {
    if (_startDate == null && _endDate == null) return true;
    if (_startDate != null && _endDate == null) return date.isAfter(_startDate!.subtract(const Duration(seconds: 1)));
    if (_startDate == null && _endDate != null) return date.isBefore(_endDate!.add(const Duration(seconds: 1)));
    if (_startDate != null && _endDate != null) {
      return date.isAfter(_startDate!.subtract(const Duration(seconds: 1))) &&
             date.isBefore(_endDate!.add(const Duration(seconds: 1)));
    }
    return true;
  }

  String _formatCurrency(double amount) {
    if (amount == 0) return "Rp 0";
    String amountStr = amount.abs().toStringAsFixed(0);
    String result = '';
    int count = 0;
    for (int i = amountStr.length - 1; i >= 0; i--) {
      result = amountStr[i] + result;
      count++;
      if (count % 3 == 0 && i != 0) {
        result = '.$result';
      }
    }
    final sign = amount < 0 ? '-' : '';
    return '$sign Rp $result';
  }

  String _formatDate(DateTime date) {
    final monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    if (date.year == today.year && date.month == today.month && date.day == today.day) {
      return 'Today';
    } else if (date.year == yesterday.year && date.month == yesterday.month && date.day == yesterday.day) {
      return 'Yesterday';
    }
    return '${date.day} ${monthNames[date.month - 1]} ${date.year}';
  }

  Color _getProfitColor(double amount) {
    if (amount > 0) return Colors.green;
    if (amount < 0) return Colors.red;
    return Colors.grey;
  }

  String _getProfitStatus(double profit) {
    if (profit > 0) return '💰 PROFITABLE';
    if (profit < 0) return '⚠️ OPERATING AT LOSS';
    return '⚖️ BREAK EVEN';
  }

  String _getProfitMessage(double profit) {
    if (profit > 0) {
      if (profit / _totalIncome > 0.3) return 'Excellent performance! 🎉';
      if (profit / _totalIncome > 0.15) return 'Good profit margin! 👍';
      return 'Moderate profit margin';
    } else if (profit < 0) {
      if (profit.abs() / _totalIncome > 0.3) return 'Critical situation! 🚨';
      if (profit.abs() / _totalIncome > 0.15) return 'Needs improvement';
      return 'Slight loss';
    }
    return 'No profit or loss';
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.purple[800]!, Colors.purple[600]!],
        ),
        borderRadius: const BorderRadius.only(bottomLeft: Radius.circular(20), bottomRight: Radius.circular(20)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('💰 Profit & Loss Analysis', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: Colors.white)),
          const SizedBox(height: 8),
          Text('Track your business financial performance', style: TextStyle(fontSize: 14, color: Colors.white.withOpacity(0.9))),
        ],
      ),
    );
  }

  Widget _buildFilterBar() {
    return Card(
      margin: const EdgeInsets.all(16),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(children: [Icon(Icons.date_range, size: 20), SizedBox(width: 8), Text('Time Period', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16))]),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _periods.map((period) {
                final isSelected = _selectedPeriod == period['value'];
                return ChoiceChip(
                  label: Text(period['label']!),
                  selected: isSelected,
                  onSelected: (selected) {
                    if (selected) {
                      _setDateRange(period['value']!);
                      _loadProfitData();
                    }
                  },
                  backgroundColor: isSelected ? Colors.purple[50] : Colors.grey[50],
                  selectedColor: Colors.purple[100],
                  labelStyle: TextStyle(color: isSelected ? Colors.purple : Colors.grey[700], fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal),
                );
              }).toList(),
            ),
            if (_selectedPeriod != 'all' && _startDate != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.grey[50], borderRadius: BorderRadius.circular(8)),
                child: Row(children: [
                  Icon(Icons.calendar_today, size: 16, color: Colors.grey[600]),
                  const SizedBox(width: 8),
                  Text('${_formatDate(_startDate!)} - ${_formatDate(_endDate ?? DateTime.now())}', style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                ]),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String title, String value, String subtitle, IconData icon, Color color) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(8)), child: Icon(icon, size: 20, color: color)),
              const Spacer(),
            ]),
            const SizedBox(height: 12),
            Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text(title, style: TextStyle(fontSize: 13, color: Colors.grey[600])),
            if (subtitle.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(subtitle, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildProfitSummary() {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
            colors: _netProfit > 0 ? [Colors.green[50]!, Colors.green[100]!] : _netProfit < 0 ? [Colors.red[50]!, Colors.red[100]!] : [Colors.grey[50]!, Colors.grey[100]!],
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(_netProfit > 0 ? Icons.trending_up : Icons.trending_down, color: _getProfitColor(_netProfit), size: 24),
                const SizedBox(width: 8),
                Text(_getProfitStatus(_netProfit), style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: _getProfitColor(_netProfit))),
              ]),
              const SizedBox(height: 12),
              Text(_formatCurrency(_netProfit), style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: _getProfitColor(_netProfit))),
              const SizedBox(height: 8),
              Text(_getProfitMessage(_netProfit), style: TextStyle(fontSize: 14, color: Colors.grey[700]), textAlign: TextAlign.center),
              const SizedBox(height: 16),
              Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                Column(children: [
                  Text(_formatCurrency(_totalIncome), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.green)),
                  const Text('Income', style: TextStyle(fontSize: 12, color: Colors.grey)),
                ]),
                Column(children: [
                  Text(_formatCurrency(_totalExpense), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.red)),
                  const Text('Expenses', style: TextStyle(fontSize: 12, color: Colors.grey)),
                ]),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTransactionItem(Map<String, dynamic> transaction) {
    final isIncome = transaction['type'] == 'income';
    final amount = transaction['amount'] as double;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Container(
          width: 40, height: 40,
          decoration: BoxDecoration(color: isIncome ? Colors.green[100] : Colors.red[100], shape: BoxShape.circle),
          child: Icon(isIncome ? Icons.arrow_downward : Icons.arrow_upward, color: isIncome ? Colors.green : Colors.red, size: 20),
        ),
        title: Text(transaction['description'], style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
        subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(height: 2),
          Text(_formatDate(transaction['date']), style: TextStyle(fontSize: 12, color: Colors.grey[600])),
          if (transaction['category'] != null) ...[
            const SizedBox(height: 2),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(color: Colors.grey[100], borderRadius: BorderRadius.circular(4)),
              child: Text(transaction['category'], style: TextStyle(fontSize: 10, color: Colors.grey[600])),
            ),
          ],
        ]),
        trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text('${isIncome ? '+' : '-'}${_formatCurrency(amount)}', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: isIncome ? Colors.green : Colors.red)),
          const SizedBox(height: 2),
          Text(isIncome ? 'Income' : 'Expense', style: TextStyle(fontSize: 11, color: Colors.grey[500])),
        ]),
      ),
    );
  }

  Widget _buildInsightsSection() {
    if (_topIncomeSources.isEmpty && _topExpenses.isEmpty) return Container();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Padding(padding: EdgeInsets.symmetric(horizontal: 16, vertical: 16), child: Text('📊 Business Insights', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700))),
      if (_topIncomeSources.isNotEmpty) _buildInsightCard('Top Selling Items', _topIncomeSources.map((item) => InsightItem(label: item.name, value: _formatCurrency(item.amount), subtitle: '${item.count} sales')).toList(), Colors.green),
      if (_topExpenses.isNotEmpty) ...[
        const SizedBox(height: 12),
        _buildInsightCard('Major Expenses', _topExpenses.map((expense) => InsightItem(label: expense['name'] as String, value: _formatCurrency(expense['amount'] as double), subtitle: expense['vendor'] as String? ?? 'Vendor')).toList(), Colors.red),
      ],
    ]);
  }

  Widget _buildInsightCard(String title, List<InsightItem> items, Color color) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(padding: const EdgeInsets.all(4), decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(6)), child: Icon(color == Colors.green ? Icons.star : Icons.warning, size: 16, color: color)),
            const SizedBox(width: 8),
            Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
          ]),
          const SizedBox(height: 12),
          ...items.map((item) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(item.label, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis),
                if (item.subtitle != null) ...[
                  const SizedBox(height: 2),
                  Text(item.subtitle!, style: TextStyle(fontSize: 11, color: Colors.grey[600])),
                ],
              ])),
              const SizedBox(width: 8),
              Text(item.value, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: color)),
            ]),
          )).toList(),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(  // ← ADD THIS APP BAR
        title: const Text('💰 Profit Analysis'),
        backgroundColor: Colors.purple[800],
        foregroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadProfitData,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Analyzing financial data...'),
                ],
              ),
            )
          : _error.isNotEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.error_outline,
                          size: 60,
                          color: Colors.red[400],
                        ),
                        const SizedBox(height: 20),
                        const Text(
                          'Unable to load data',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _error,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.grey),
                        ),
                        const SizedBox(height: 20),
                        ElevatedButton(
                          onPressed: _loadProfitData,
                          child: const Text('Try Again'),
                        ),
                      ],
                    ),
                  ),
                )
              : CustomScrollView(
                  slivers: [
                    // REMOVE the _buildHeader() Sliver since we now have AppBar
                    SliverToBoxAdapter(child: _buildFilterBar()),
                    
                    // Stats Grid
                    SliverToBoxAdapter(
                      child: GridView.count(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        crossAxisCount: isDesktop ? 4 : isTablet ? 2 : 2,
                        childAspectRatio: isDesktop ? 1.3 : 1.4,
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        children: [
                          _buildStatCard(
                            'Total Income',
                            _formatCurrency(_totalIncome),
                            '${_recentTransactions.where((t) => t['type'] == 'income').length} transactions',
                            Icons.trending_up,
                            Colors.green,
                          ),
                          _buildStatCard(
                            'Total Expenses',
                            _formatCurrency(_totalExpense),
                            '${_recentTransactions.where((t) => t['type'] == 'expense').length} transactions',
                            Icons.trending_down,
                            Colors.red,
                          ),
                          _buildStatCard(
                            'Net Profit',
                            _formatCurrency(_netProfit),
                            _netProfit > 0 ? 'Profit' : 'Loss',
                            _netProfit > 0 ? Icons.attach_money : Icons.money_off,
                            _getProfitColor(_netProfit),
                          ),
                          _buildStatCard(
                            'Profit Margin',
                            '${_profitMargin.toStringAsFixed(1)}%',
                            _profitMargin > 20 ? 'Excellent' : 'Standard',
                            Icons.percent,
                            _profitMargin > 0 ? Colors.blue : Colors.orange,
                          ),
                        ],
                      ),
                    ),
                    
                    // Profit Summary
                    SliverToBoxAdapter(child: _buildProfitSummary()),
                    
                    // Business Insights
                    if (_topIncomeSources.isNotEmpty || _topExpenses.isNotEmpty)
                      SliverToBoxAdapter(child: _buildInsightsSection()),
                    
                    // Recent Transactions Header
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              '📝 Recent Transactions',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            TextButton(
                              onPressed: () {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Showing all transactions'),
                                    duration: Duration(seconds: 1),
                                  ),
                                );
                              },
                              child: const Text('View All'),
                            ),
                          ],
                        ),
                      ),
                    ),
                    
                    // Transactions List
                    if (_recentTransactions.isNotEmpty)
                      SliverList(
                        delegate: SliverChildBuilderDelegate(
                          (context, index) {
                            if (index >= _recentTransactions.length) return null;
                            return _buildTransactionItem(_recentTransactions[index]);
                          },
                          childCount: _recentTransactions.length > 10 ? 10 : _recentTransactions.length,
                        ),
                      )
                    else
                      SliverToBoxAdapter(
                        child: Padding(
                          padding: const EdgeInsets.all(32),
                          child: Center(
                            child: Column(
                              children: [
                                Icon(
                                  Icons.receipt_long,
                                  size: 60,
                                  color: Colors.grey[300],
                                ),
                                const SizedBox(height: 16),
                                const Text(
                                  'No transactions found',
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.grey,
                                  ),
                                ),
                                Text(
                                  'for the selected period',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey[400],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    
                    // Bottom padding
                    const SliverToBoxAdapter(child: SizedBox(height: 80)),
                  ],
                ),
      // REMOVE the floatingActionButton since we moved refresh to AppBar
    );
  }


}