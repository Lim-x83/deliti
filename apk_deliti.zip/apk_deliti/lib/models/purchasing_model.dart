class PurchasingItem {
  final int id;
  final String namaBarang;
  final String kode; // New: PUR-1, PUR-2, etc.
  final int jumlahBarang;
  final String satuanKuantitas;
  final String? lokasiBarang;
  final DateTime? expiredDate;
  final double harga;
  final String vendor;
  final DateTime tanggalTransaksi;
  final DateTime createdAt;

  PurchasingItem({
    required this.id,
    required this.namaBarang,
    required this.kode,
    required this.jumlahBarang,
    required this.satuanKuantitas,
    this.lokasiBarang,
    this.expiredDate,
    required this.harga,
    required this.vendor,
    required this.tanggalTransaksi,
    required this.createdAt,
  });

  factory PurchasingItem.fromJson(Map<String, dynamic> json) {
    return PurchasingItem(
      id: json['id'] ?? 0,
      namaBarang: json['nama_barang'] ?? '',
      kode: json['kode'] ?? '', // New field
      jumlahBarang: json['jumlah_barang'] ?? 0,
      satuanKuantitas: json['satuan_kuantitas'] ?? '',
      lokasiBarang: json['lokasi_barang'],
      expiredDate: json['expired_date'] != null 
          ? DateTime.parse(json['expired_date']) 
          : null,
      harga: double.parse(json['harga'].toString()),
      vendor: json['vendor'] ?? '',
      tanggalTransaksi: DateTime.parse(json['tanggal_transaksi']),
      createdAt: DateTime.parse(json['created_at']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'nama_barang': namaBarang,
      'kode': kode,
      'jumlah_barang': jumlahBarang,
      'satuan_kuantitas': satuanKuantitas,
      'lokasi_barang': lokasiBarang,
      'expired_date': expiredDate?.toIso8601String(),
      'harga': harga,
      'vendor': vendor,
      'tanggal_transaksi': tanggalTransaksi.toIso8601String(),
    };
  }

  double get totalHarga => harga * jumlahBarang;
}