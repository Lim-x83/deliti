class ArModel {
  final int id;
  final String nama;
  final String? deskripsi;
  final double jumlah;
  final DateTime tanggal;
  final DateTime createdAt;

  ArModel({
    required this.id,
    required this.nama,
    this.deskripsi,
    required this.jumlah,
    required this.tanggal,
    required this.createdAt,
  });

  factory ArModel.fromJson(Map<String, dynamic> json) {
    return ArModel(
      id: int.parse(json['id'].toString()),
      nama: json['nama'] ?? '',
      deskripsi: json['deskripsi'],
      jumlah: double.parse(json['jumlah'].toString()),
      tanggal: DateTime.parse(json['tanggal'].toString()),
      createdAt: DateTime.parse(json['created_at'].toString()),
    );
  }
}