class Article {
  final int id;
  final String title;
  final String content;
  final String author;
  final String category;
  final String? imagePath;
  final int views;
  final bool isPublished;
  final DateTime createdAt;
  final DateTime updatedAt;
  

  Article({
    required this.id,
    required this.title,
    required this.content,
    this.author = 'Admin',
    this.category = 'General',
    this.imagePath,
    this.views = 0,
    this.isPublished = true,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Article.fromJson(Map<String, dynamic> json) {
    return Article(
      id: json['id'] ?? 0,
      title: json['title'] ?? '',
      content: json['content'] ?? '',
      author: json['author'] ?? 'Admin',
      category: json['category'] ?? 'General',
      imagePath: json['image_path'],
      views: json['views'] ?? 0,
      isPublished: (json['is_published'] ?? 1) == 1,
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'content': content,
      'author': author,
      'category': category,
      'image_path': imagePath,
      'is_published': isPublished ? 1 : 0,
    };
  }

  String get excerpt {
    if (content.length <= 150) return content;
    return '${content.substring(0, 150)}...';
  }

  String get timeAgo {
    final now = DateTime.now();
    final difference = now.difference(createdAt);
    
    if (difference.inDays > 365) {
      return '${(difference.inDays / 365).floor()} years ago';
    } else if (difference.inDays > 30) {
      return '${(difference.inDays / 30).floor()} months ago';
    } else if (difference.inDays > 0) {
      return '${difference.inDays} days ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours} hours ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes} minutes ago';
    } else {
      return 'Just now';
    }
  }



  
}