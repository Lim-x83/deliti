// models/user_model.dart
class User {
  final int id;
  final String name;
  final String email;
  final String phone;
  final String role; // ← MAKE SURE THIS EXISTS
  
  User({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.role, // ← AND THIS
  });
  
  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'],
      name: json['name'],
      email: json['email'],
      phone: json['phone'] ?? '',
      role: json['role'] ?? 'user', // ← DEFAULT TO 'user'
    );
  }
  
  // Add this helper method
  bool get isAdmin => role == 'admin';
}