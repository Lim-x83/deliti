class AccountPayable {
  final int id;
  final String namaBarang;
  final String kode; // New: PUR-1, PUR-2, etc.
  final int jumlahBarang;
  final String satuanKuantitas;
  final String? lokasiBarang;
  final DateTime? expiredDate;
  final double harga;
  final String vendor;
  final DateTime tanggalTransaksi;
  final String status; // unpaid, partial, paid, overdue
  final DateTime? tanggalBayar;
  final DateTime createdAt;
  final DateTime updatedAt;

  AccountPayable({
    required this.id,
    required this.namaBarang,
    required this.kode,
    required this.jumlahBarang,
    required this.satuanKuantitas,
    this.lokasiBarang,
    this.expiredDate,
    required this.harga,
    required this.vendor,
    required this.tanggalTransaksi,
    required this.status,
    this.tanggalBayar,
    required this.createdAt,
    required this.updatedAt,
  });

  factory AccountPayable.fromJson(Map<String, dynamic> json) {
    return AccountPayable(
      id: json['id'] ?? 0,
      namaBarang: json['nama_barang'] ?? '',
      kode: json['kode'] ?? '', // New field
      jumlahBarang: json['jumlah_barang'] ?? 0,
      satuanKuantitas: json['satuan_kuantitas'] ?? '',
      lokasiBarang: json['lokasi_barang'],
      expiredDate: json['expired_date'] != null 
          ? DateTime.parse(json['expired_date']) 
          : null,
      harga: double.parse(json['harga'].toString()),
      vendor: json['vendor'] ?? '',
      tanggalTransaksi: DateTime.parse(json['tanggal_transaksi']),
      status: json['status'] ?? 'unpaid',
      tanggalBayar: json['tanggal_bayar'] != null 
          ? DateTime.parse(json['tanggal_bayar']) 
          : null,
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nama_barang': namaBarang,
      'kode': kode,
      'jumlah_barang': jumlahBarang,
      'satuan_kuantitas': satuanKuantitas,
      'lokasi_barang': lokasiBarang,
      'expired_date': expiredDate?.toIso8601String(),
      'harga': harga,
      'vendor': vendor,
      'tanggal_transaksi': tanggalTransaksi.toIso8601String(),
      'status': status,
      'tanggal_bayar': tanggalBayar?.toIso8601String(),
    };
  }

  double get totalHarga => harga * jumlahBarang;
  
  bool get isUnpaid => status == 'unpaid' || status == 'overdue';
  bool get isPartial => status == 'partial';
  bool get isPaid => status == 'paid';
}