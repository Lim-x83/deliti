// models/user_profile.dart
class UserProfile {
  final int id;
  final String name;
  final String email;
  final String phone;
  final String? profilePicture;
  final DateTime joinedDate;
  final String role; // ← ADD THIS
  
  UserProfile({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    this.profilePicture,
    required this.joinedDate,
    required this.role, // ← ADD THIS
  });
  
  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      id: json['id'],
      name: json['name'],
      email: json['email'],
      phone: json['phone'] ?? '',
      profilePicture: json['profile_picture'],
      joinedDate: DateTime.parse(json['created_at']),
      role: json['role'] ?? 'user', // ← ADD THIS
    );
  }
  
  bool get isAdmin => role == 'admin'; // ← ADD THIS
  
  // ... rest of your methods
}