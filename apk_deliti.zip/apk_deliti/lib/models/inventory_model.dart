class InventoryItem {
  final int id;
  final String namaBarang;
  final String kode; // New: PUR-1, PUR-2, etc.
  final int jumlahBarang;
  final String satuanKuantitas;
  final String? lokasiBarang;
  final DateTime? expiredDate;
  final DateTime createdAt;
  final DateTime updatedAt;

  // Optional: Additional info from purchasing table
  final double? harga;
  final String? vendor;
  final DateTime? tanggalTransaksi;

  InventoryItem({
    required this.id,
    required this.namaBarang,
    required this.kode,
    required this.jumlahBarang,
    required this.satuanKuantitas,
    this.lokasiBarang,
    this.expiredDate,
    required this.createdAt,
    required this.updatedAt,
    this.harga,
    this.vendor,
    this.tanggalTransaksi,
  });

  factory InventoryItem.fromJson(Map<String, dynamic> json) {
    return InventoryItem(
      id: json['id'] ?? 0,
      namaBarang: json['nama_barang'] ?? '',
      kode: json['kode'] ?? '', // New field
      jumlahBarang: json['jumlah_barang'] ?? 0,
      satuanKuantitas: json['satuan_kuantitas'] ?? '',
      lokasiBarang: json['lokasi_barang'],
      expiredDate: json['expired_date'] != null 
          ? DateTime.parse(json['expired_date']) 
          : null,
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      harga: json['harga'] != null ? double.parse(json['harga'].toString()) : null,
      vendor: json['vendor'],
      tanggalTransaksi: json['tanggal_transaksi'] != null 
          ? DateTime.parse(json['tanggal_transaksi']) 
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nama_barang': namaBarang,
      'kode': kode,
      'jumlah_barang': jumlahBarang,
      'satuan_kuantitas': satuanKuantitas,
      'lokasi_barang': lokasiBarang,
      'expired_date': expiredDate?.toIso8601String(),
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }
}