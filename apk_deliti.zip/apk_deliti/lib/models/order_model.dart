// lib/models/order_model.dart
import 'package:flutter/material.dart';

class OrderItem {
  final int id;
  final int menuItemId;
  final String menuItemName;
  final int quantity;
  final double price;
  final double itemTotal;
  
  OrderItem({
    required this.id,
    required this.menuItemId,
    required this.menuItemName,
    required this.quantity,
    required this.price,
    required this.itemTotal,
  });
  
  factory OrderItem.fromJson(Map<String, dynamic> json) {
    return OrderItem(
      id: json['id'] ?? 0,
      menuItemId: json['menu_item_id'] ?? 0,
      menuItemName: json['menu_item_name'] ?? json['name'] ?? 'Unknown Item',
      quantity: json['quantity'] ?? 1,
      price: double.tryParse(json['price'].toString()) ?? 0.0,
      itemTotal: (json['quantity'] ?? 1) * (double.tryParse(json['price'].toString()) ?? 0.0),
    );
  }

  void operator [](String other) {}
}

  class Order {
    final int id;
    final int userId;
    final double totalPrice;
    final String status;
    final DateTime createdAt;
    final List<OrderItem> items;
    
    Order({
      required this.id,
      required this.userId,
      required this.totalPrice,
      required this.status,
      required this.createdAt,
      required this.items,
    });

  Order copyWith({
    int? id,
    int? userId,
    double? totalPrice,
    String? status,
    DateTime? createdAt,
    List<OrderItem>? items,
  }) {
    return Order(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      totalPrice: totalPrice ?? this.totalPrice,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      items: items ?? this.items,
    );
  }
  
  factory Order.fromJson(Map<String, dynamic> json) {
    return Order(
      id: json['id'] ?? 0,
      userId: json['user_id'] ?? 0,
      totalPrice: double.tryParse(json['total_price'].toString()) ?? 0.0,
      status: json['status'] ?? 'pending',
      createdAt: DateTime.parse(json['created_at'] ?? DateTime.now().toIso8601String()),
      items: (json['items'] as List<dynamic>?)
          ?.map((item) => OrderItem.fromJson(Map<String, dynamic>.from(item)))
          .toList() ?? [],
    );
  }
  
  // Helper getters
  bool get isPending => status == 'pending';
  bool get isCancelled => status == 'cancelled';
  bool get isCompleted => status == 'completed';
  
  Color get statusColor {
    switch (status) {
      case 'pending': return Colors.orange;
      case 'preparing': return Colors.blue;
      case 'cooking': return Colors.deepOrange;
      case 'ready': return Colors.green;
      case 'delivering': return Colors.purple;
      case 'completed': return Colors.green[800]!;
      case 'cancelled': return Colors.red;
      default: return Colors.grey;
    }
  }
  
  String get statusDisplay {
    switch (status) {
      case 'pending': return 'Pending';
      case 'preparing': return 'Preparing';
      case 'cooking': return 'Cooking';
      case 'ready': return 'Ready';
      case 'delivering': return 'Delivering';
      case 'completed': return 'Completed';
      case 'cancelled': return 'Cancelled';
      default: return status;
    }
  }
}